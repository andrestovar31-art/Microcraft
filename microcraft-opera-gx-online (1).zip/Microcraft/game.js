var NETON=false,netTgt=function(){return P},netHurt=function(){},netArrowHit=function(){return null},netBoom=function(){},netFar=function(x){return Math.abs(x-P.x)>90};
const cv=document.getElementById('c'),g=cv.getContext('2d');
const T=32,H=60,VW=cv.width,VH=cv.height;let W=140,OX=0;
const B=[null,
{n:'Césped',c:'#6fae48',e:'#4d8a2f'},
{n:'Tierra',c:'#a9744a',e:'#7e5230'},
{n:'Piedra',c:'#9a9a9a',e:'#6d6d6d'},
{n:'Tronco',c:'#8a5a2b',e:'#5e3b17'},
{n:'Hojas',c:'#4f9a3a',e:'#34702a'},
{n:'Tablas',c:'#d2a65e',e:'#a07a38'},
{n:'Carbón',c:'#9a9a9a',e:'#6d6d6d'},
{n:'Hierro',c:'#9a9a9a',e:'#6d6d6d'},
{n:'Diamante',c:'#9a9a9a',e:'#6d6d6d'},
{n:'Agua',c:'#3d7fe0',e:'#2a5fb0'},
{n:'Lava',c:'#e8541a',e:'#a03a10'}];
B[18]={n:'Mesa de crafteo',c:'#d2a65e',e:'#a07a38'};
B[19]={n:'Horno',c:'#9a9a9a',e:'#6d6d6d'};
B[30]={n:'Puerta',c:'#b98a45',e:'#6b4423'};B[31]={n:'Puerta',c:'#b98a45',e:'#6b4423'};B[32]={n:'Trampilla',c:'#c99a52',e:'#7a5230'};B[33]={n:'Trampilla',c:'#c99a52',e:'#7a5230'};B[34]={n:'Vidrio',c:'#c8e6f0',e:'#8fb8c8'};B[35]={n:'Arena',c:'#e6d49a',e:'#c4b070'};
let w=new Uint8Array(W*H),LV=new Uint8Array(W*H);
const get=(x,y)=>x<0||y<0||x>=W||y>=H?3:w[y*W+x];
let set=(x,y,v)=>{if(x>=0&&y>=0&&x<W&&y<H){w[y*W+x]=v;LV[y*W+x]=0}};
const hgt=x=>{x+=OX;return Math.round(24+4*Math.sin(x*.11)+3*Math.sin(x*.037+1)+2*Math.sin(x*.23))};
const L=27;
function gen(x0,x1){const n=x1-x0,sc=n/140;
 for(let x=x0;x<x1;x++){const h=hgt(x);for(let y=h;y<H;y++)set(x,y,y==h?1:y<h+4?2:3)}
 for(let i=0;i<70*sc;i++){const cx=x0+(Math.random()*n|0),cy=30+(Math.random()*25|0),r=1+Math.random()*2.5;
  for(let dx=-3;dx<=3;dx++)for(let dy=-3;dy<=3;dy++)if(dx*dx+dy*dy<r*r&&cy+dy>hgt(cx+dx)+4)set(cx+dx,cy+dy,0)}
 for(let x=x0;x<x1;x++){const h=hgt(x);for(let y=L;y<h;y++)set(x,y,10)}
 for(let x=x0;x<x1;x++){const h=hgt(x);if(h>=L-1)for(let y=h;y<h+3;y++)if(get(x,y)==1||get(x,y)==2)set(x,y,35)}
 for(let i=0;i<500*sc;i++){const ox=x0+(Math.random()*n|0),oy=hgt(ox)+6+Math.random()*(H-hgt(ox)-8)|0;const t=oy>46&&Math.random()<.35?9:oy>34&&Math.random()<.5?8:7;for(let k=0;k<1+Math.random()*3;k++){const a=ox+(Math.random()*3|0)-1,b2=oy+(Math.random()*3|0)-1;if(get(a,b2)==3)set(a,b2,t)}}
 for(let i=0;i<10*sc;i++){const lx=x0+(Math.random()*n|0),ly=48+Math.random()*8|0;for(let dx=-3;dx<=3;dx++)for(let dy=-1;dy<=1;dy++)if(dx*dx/9+dy*dy<=1.2)set(lx+dx,ly+dy,11)}
 for(let x=x0;x<x1;x++)for(let y=52;y<H;y++)if(!get(x,y))set(x,y,11);
 for(let x=x0+4;x<x1-4;x+=5+Math.random()*5|0){const h=hgt(x);
  if(h>L)continue;for(let k=1;k<=4;k++)set(x,h-k,4);
  for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=1;dy++)if(!get(x+dx,h-5+dy)&&(Math.abs(dx)+Math.abs(dy)<4))set(x+dx,h-5+dy,5)}}
gen(0,W);
function extend(dir){const C=60;if(W+C>6000)return;const oW=W,nW=W+C,nw=new Uint8Array(nW*H),nl=new Uint8Array(nW*H),off=dir<0?C:0;
 for(let y=0;y<H;y++){nw.set(w.subarray(y*oW,y*oW+oW),y*nW+off);nl.set(LV.subarray(y*oW,y*oW+oW),y*nW+off)}
 w=nw;LV=nl;W=nW;
 if(dir<0){OX-=C;P.x+=C;cam.x+=C*T;mtx+=C;mp=0;[ANI,MON,DR,HK,WV,ARR,EX].forEach(l=>l.forEach(e=>e.x+=C))}
 gen(dir<0?0:oW,dir<0?C:W)}
const inv=new Array(60).fill(0),S=new Array(31).fill(0);let drag=-1;inv[2]=8;inv[6]=4;
let sel=1,open=0,msg='',mt=0;let mp=0,mtx=-1,mty=-1;const HD=[0,54,45,180,108,18,90,225,315,450];HD[18]=90;HD[19]=120;HD[30]=HD[31]=HD[32]=HD[33]=60;HD[34]=24;HD[35]=45;const spd=k=>{const h=S[sel-1];let ty='',t=0;if(h>=13&&h<=16){ty='p';t=h-12}else if(h>=44&&h<=47){ty='a';t=h-43}else if(h>=48&&h<=51){ty='v';t=h-47}
 const hard=k==3||k>6&&k<10||k==19,wood=k==4||k==5||k==6||k==18||(k>=30&&k<=33),soft=k==1||k==2||k==35;
 if(hard)return ty=='p'?[1,2,4,6,8][t]:1;
 if(wood)return ty=='a'?[1,2.5,4,6,8][t]:ty=='p'?[1,1.2,1.4,1.7,2][t]:1;
 if(soft)return ty=='v'?[1,2.5,4,6,8][t]:ty=='p'?[1,1.2,1.4,1.7,2][t]:1;
 return 1};
let flash=0,HP=20,rg=0,hurtT=0;const P={x:W/2,y:hgt(W/2|0)-3,vx:0,vy:0,w:.7,h:1.7,gnd:false,face:1};
const keys={};let mx=0,my=0,mdown=0,cam={x:0,y:0},tm=0;
addEventListener('keydown',e=>{keys[e.code]=1;if(e.code>='Digit1'&&e.code<='Digit9')sel=+e.code.slice(5);if(e.code=='Space')e.preventDefault();if(e.code=='KeyE')open=!open;if(e.code=='KeyF'&&(cre||ironFull()))P.fly=!P.fly;if(e.code=='KeyQ'&&S[sel-1]==52&&cdn<=0&&!open&&!ske)hook();if(e.code=='Escape'){open=0;ske=0}});
addEventListener('keyup',e=>keys[e.code]=0);
function pos(e){const r=cv.getBoundingClientRect();mx=(e.clientX-r.left)*VW/r.width;my=(e.clientY-r.top)*VH/r.height}
let tmode=0;const fixE=e=>{const t=e.pointerType=='touch';return{clientX:e.clientX,clientY:e.clientY,button:t&&tmode?2:e.button,buttons:t&&tmode?2:e.buttons}};
addEventListener('pointermove',e0=>{if(e0.pointerType=='touch'&&e0.target!==cv)return;const e=fixE(e0);pos(e);if(ske&&e.buttons)skPtr(e.buttons&2?2:0,1);if(e.buttons){mdown=e.buttons&2?2:1;if(my>VH-50)mdown=0}});addEventListener('mousemove',pos);
cv.addEventListener('pointerdown',e0=>{const e=fixE(e0);pos(e);if(ske){skPtr(e.button==2?2:0,0);mdown=0;return}if(mx<118&&my<26){open=!open;mdown=0;return}if(open){mdown=0;clickInv();return}if(e.button==2){const tx=Math.floor((mx+cam.x)/T),ty=Math.floor((my+cam.y)/T);if(isOp(get(tx,ty))&&Math.hypot(tx+.5-P.x-P.w/2,ty+.5-P.y-P.h/2)<5.5){tgl(tx,ty);mdown=0;return}}
 {const h=S[sel-1];if(e.button==2&&(h==36||h==37)&&HP<20){if(!cre)inv[h]--;HP=Math.min(20,HP+(h==37?8:3));say('¡Ñam!');mdown=0;return}}
 {const h=S[sel-1];if(h==52&&(e.button==0||e.button==2)){if(cdn<=0){if(e.button==2)wave();else sweep()}mdown=0;return}}
 {const h=S[sel-1];if((h==28||h==29)&&(e.button==0||e.button==2)){if(cdn<=0)shoot(h,e.button==2);mdown=0;return}}
 {const h=S[sel-1];if(h==39&&(e.button==0||e.button==2)){if(cdn<=0)jd(e.button==2);mdown=0;return}}
 if(e.button==0){const wx=(mx+cam.x)/T,wy=(my+cam.y)/T,a=ANI.concat(MON).find(a=>wx>=a.x-.2&&wx<=a.x+a.w+.2&&wy>=a.y-.2&&wy<=a.y+a.h+.2);if(a&&Math.hypot(a.x+a.w/2-P.x-P.w/2,a.y+a.h/2-P.y-P.h/2)<4){hitAni(a);mdown=0;return}}mdown=e.button==2?2:1;if(my>VH-50){const i=Math.floor((mx-VW/2+225)/50)+1;if(i>=1&&i<=9){sel=i;mdown=0}}});
addEventListener('pointerup',e=>{if(e.pointerType=='touch'&&e.target!==cv)return;pos(e);mdown=0;dropInv();if(ske)skSave()});addEventListener('pointercancel',()=>{mdown=0;drag=-1});addEventListener('blur',()=>{mdown=0;for(const k in keys)keys[k]=0});
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('wheel',e=>{e.preventDefault();sel=(sel-1+(e.deltaY>0?1:8))%9+1},{passive:false});
const hit=(x,y)=>{for(let i=Math.floor(x);i<=Math.floor(x+P.w);i++)for(let j=Math.floor(y);j<=Math.floor(y+P.h);j++){const q=get(i,j);if(q&&q!=4&&q!=5&&(q<10||q>17&&q!=31&&q!=33))return true};return false};
function step(){if(P.x<16)extend(-1);else if(P.x>W-16)extend(1);if(mdown!=1||open)mp=0;upd();
 for(let id=1;id<53;id++){const p=S.indexOf(id);if(inv[id]>0&&p<0){const e=S.indexOf(0);if(e>=0)S[e]=id}else if(inv[id]<1&&p>=0)S[p]=0}
 const L=keys.KeyA||keys.ArrowLeft,R=keys.KeyD||keys.ArrowRight,J=keys.KeyW||keys.ArrowUp||keys.Space;
 P.vx=sonicVx(L,R);if(P.vx)P.face=P.vx>0?1:-1;
 const cxp=Math.floor(P.x+P.w/2),qx=get(cxp,Math.floor(P.y+P.h*.6)),qf=get(cxp,Math.floor(P.y+P.h-.1)),qh=get(cxp,Math.floor(P.y+.2));
 if(qx==11||qf==11){if((P.lv=(P.lv||0)+1)%25==1){hurt(3);flash=30}}else P.lv=0;
 if((cre||ironFull())&&P.fly){P.vy=J?-.2:(keys.KeyS||keys.ArrowDown)?.2:0;P.vx*=1.8;P.fs=null}else if(qx==10||qf==10||qx==11||qf==11){P.vx*=.6;P.vy=Math.min(P.vy+.006,.08);if(J)P.vy=(qh==10||qh==11)?-.1:-.3}
 else{if(J&&P.gnd){P.vy=-.34;P.gnd=false}else if(J&&!jp&&!P.gnd&&S[sel-1]==52&&!P.dj){P.vy=-.3;P.dj=1}if(P.gnd)P.dj=0;P.vy=Math.min(P.vy+.02,.6)}jp=J;
 P.x+=P.vx;if(hit(P.x,P.y)){P.x-=P.vx}
 if(P.vy>0&&P.fs==null)P.fs=P.y;P.y+=P.vy;P.gnd=false;if(hit(P.x,P.y)){P.y-=P.vy;if(P.vy>0){P.gnd=true;if(P.fs!=null&&!(qx==10||qf==10||qx==11||qf==11))hurt(Math.floor(P.y-P.fs-3));P.fs=null}P.vy=0}if(qx==10||qf==10||qx==11||qf==11||P.vy<0)P.fs=null;
 P.x=Math.max(0,Math.min(W-P.w,P.x));
 cam.x+=((P.x+P.w/2)*T-VW/2-cam.x)*.15;cam.y+=((P.y+P.h/2)*T-VH/2-cam.y)*.15;
 cam.x=Math.max(0,Math.min(W*T-VW,cam.x));cam.y=Math.max(0,Math.min(H*T-VH,cam.y));
 if(!open&&!ske&&mdown&&my<VH-50&&(tm=(tm+1)%8)==1){
  const tx=Math.floor((mx+cam.x)/T),ty=Math.floor((my+cam.y)/T);
  const d=Math.hypot(tx+.5-P.x-P.w/2,ty+.5-P.y-P.h/2);
  if(d<5.5){
   if(0){const k=get(tx,ty);if(mtx!=tx||mty!=ty){mtx=tx;mty=ty;mp=0}if(tier()>=(REQ[k]||0)){mp+=8*spd(k);if(mp>=HD[k]){drop(tx,ty,k);set(tx,ty,0);mp=0}}else say('Necesitas un pico mejor en la mano')}
   else if(mdown==2&&(!get(tx,ty)||get(tx,ty)==10||get(tx,ty)==11)&&S[sel-1]&&B[S[sel-1]]&&inv[S[sel-1]]>0){const it=S[sel-1];if(it==30){if(get(tx,ty-1)==0){set(tx,ty,30);set(tx,ty-1,30);if(hit(P.x,P.y)){set(tx,ty,0);set(tx,ty-1,0)}else dec(it)}}else{set(tx,ty,it);if(hit(P.x,P.y))set(tx,ty,0);else dec(it)}}
  }
 }
}
const TX=[];
function mk(id){const c=document.createElement('canvas');c.width=c.height=T;const x=c.getContext('2d');let s=id*97+13;const r=()=>(s=(s*16807)%2147483647)/2147483647;const b=B[id],Q=4;
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){let col=b.c,v=r();
  if(id==1){col=j<2?(v<.5?'#6fae48':'#5c9a3a'):(v<.5?'#a9744a':'#9a6a42');if(j==2&&v<.5)col='#5c9a3a'}
  else if(id==2)col=v<.3?'#98643d':v<.6?'#a9744a':'#b8835a';
  else if(id==3)col=v<.25?'#848484':v<.7?'#9a9a9a':'#aeaeae';
  else if(id==4)col=i%2?(v<.5?'#8a5a2b':'#7a4d22'):(v<.5?'#9a6a35':'#8a5a2b');
  else if(id==5)col=v<.2?'#2f6a22':v<.6?'#4f9a3a':'#62b04a';
  else if(id==6)col=j%4==3?'#a07a38':(v<.5?'#d2a65e':'#dcb36c');
  else if(id==35)col=v<.3?'#d9c78a':v<.7?'#e6d49a':'#efe0aa';
  else if(id>=30){const CL='rgba(0,0,0,0)';col=id==30?(i==0||i==7||j==0||j==7?'#6b4423':i==5&&j==4?'#e8c040':i==1||i==6?'#a8793a':'#b98a45'):id==31?(i<2?'#6b4423':CL):id==32?(j%3==0||i==0||i==7?'#7a5230':(i==3||i==4)&&j==6?'#e8c040':v<.5?'#c99a52':'#d2a65e'):id==33?(i<2?'#a07a38':CL):(i==0||j==0||i==7||j==7?'rgba(190,230,245,.6)':i==j&&i>1&&i<5?'rgba(255,255,255,.7)':'rgba(200,235,245,.2)')}
  else if(id==19)col=(i>=2&&i<=5&&j>=3&&j<=5)?(j==5?'#ff9a2e':'#2b2b2b'):(v<.3?'#848484':v<.7?'#9a9a9a':'#aeaeae');
  else if(id==18)col=j<2?(v<.5?'#6b4423':'#7a5230'):(i==3||i==4||j==5?'#8a5a2b':(v<.5?'#d2a65e':'#dcb36c'));
  else if(id>=10)col=id==10?(v<.3?'#5a98ee':'#3d7fe0'):(v<.3?'#ffb02e':'#e8541a');
  else if(id>=7){col=v<.3?'#848484':'#9a9a9a';if(r()<.3)col=['#2b2b2b','#d8a77a','#4ee3e3'][id-7]}
  x.fillStyle=col;x.fillRect(i*Q,j*Q,Q,Q)}
 if(id<10||id>17&&id!=31&&id!=33){x.strokeStyle=b.e;x.lineWidth=2;x.strokeRect(1,1,T-2,T-2);
 x.fillStyle='rgba(255,255,255,.15)';x.fillRect(2,2,T-4,3)}
 return c}
function tile(x,y,id){if(id==10)g.globalAlpha=.75;g.drawImage(TX[id]||(TX[id]=mk(id)),x,y);g.globalAlpha=1}
function draw(){
 const s=g.createLinearGradient(0,0,0,VH);s.addColorStop(0,'#bfe3f2');s.addColorStop(1,'#f4ecd8');
 g.fillStyle=s;g.fillRect(0,0,VW,VH);
 const x0=Math.floor(cam.x/T),y0=Math.floor(cam.y/T);
 for(let i=x0;i<=x0+VW/T+1;i++)for(let j=y0;j<=y0+VH/T+1;j++){const id=get(i,j);if(id&&i>=0&&j>=0&&i<W&&j<H)tile(i*T-cam.x,j*T-cam.y,id)}
 ANI.forEach(drawAni);MON.forEach(drawMon);drawArr();drawFX();
 for(const d of DR){const bob=Math.sin(d.t/15)*2;g.save();g.translate(d.x*T-cam.x-7,d.y*T-cam.y-7+bob);g.scale(.45,.45);ico(0,0,d.id);g.restore()}
 const px=P.x*T-cam.x,py=P.y*T-cam.y;
 lightDraw();jdReveal();g.fillStyle='rgba(0,0,0,.2)';g.fillRect(px+3,py+3,P.w*T,P.h*T);
 
 
 
 sonicTrail();if(!sonicBall(px,py)){skinDraw(px,py);
 g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(px,py,P.w*T,P.h*T);armorDraw(px,py);held(px,py)}sonicFX();
 const tx=Math.floor((mx+cam.x)/T),ty=Math.floor((my+cam.y)/T);
 g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=2;g.strokeRect(tx*T-cam.x,ty*T-cam.y,T,T);
 if(mp>0&&get(mtx,mty)&&(get(mtx,mty)<10||get(mtx,mty)>17)){const f=Math.min(1,mp/HD[get(mtx,mty)]),kx=mtx*T-cam.x,ky=mty*T-cam.y;g.fillStyle='rgba(0,0,0,'+(f*.45)+')';g.fillRect(kx,ky,T,T);g.strokeStyle='rgba(0,0,0,.7)';g.lineWidth=2;g.beginPath();const nn=Math.ceil(f*5);for(let i=0;i<nn;i++){g.moveTo(kx+6+i*5,ky+2);g.lineTo(kx+10+i*4,ky+16+i*3)}g.stroke()}
 for(let i=1;i<=9;i++){const bx=VW/2-225+(i-1)*50,by=VH-46;
  g.fillStyle='rgba(244,236,216,.9)';g.fillRect(bx,by,44,40);
  g.strokeStyle=i==sel?'#d23':'#3b2f20';g.lineWidth=i==sel?4:2;g.strokeRect(bx,by,44,40);
  {const id=S[i-1];if(id){g.save();g.translate(bx+10,by+4);g.scale(.7,.7);ico(0,0,id);g.restore()}}
  g.fillStyle='#3b2f20';g.font='bold 13px Georgia';if(S[i-1])g.fillText(cre?'∞':inv[S[i-1]],bx+30,by+36);g.font='10px Georgia';g.fillText(i,bx+3,by+12)}
 g.fillStyle='#3b2f20';g.font='13px Georgia';if(S[sel-1])g.fillText(nm(S[sel-1]),VW/2-225,VH-52);
 if(flash>0){flash--;g.fillStyle='rgba(230,60,20,.35)';g.fillRect(0,0,VW,VH);g.fillStyle='#fff';g.font='bold 28px Georgia';g.fillText('¡Caíste en lava!',VW/2-100,VH/2)}
 nightDraw();drawHUD();drawUI();if(ske)drawSkin();;
}
const IT={12:{n:'Palo',c:'#8a5a2b',s:'Pa'},13:{n:'Pico de madera',c:'#d2a65e',s:'Pm'},14:{n:'Pico de piedra',c:'#9a9a9a',s:'Pp'},15:{n:'Pico de hierro',c:'#d8a77a',s:'Ph'},16:{n:'Pico de diamante',c:'#4ee3e3',s:'Pd'},17:{n:'Lingote de hierro',c:'#e8c9a8',s:'Li'}};
const nm=id=>(B[id]||IT[id]).n;
IT[36]={n:'Carne cruda',c:'#d9675a',s:'Cr'};IT[37]={n:'Carne cocida',c:'#9a5a2e',s:'Cc'};
const ARM={},AN=['Casco','Peto','Pantalones','Botas'],AS=['Cs','Pt','Pn','Bt'];
for(let m=0;m<2;m++)for(let j=0;j<4;j++){const id=20+m*4+j;IT[id]={n:AN[j]+(m?' de diamante':' de hierro'),c:m?'#4ee3e3':'#cfd3d8',s:AS[j]};ARM[id]={s:j,d:[1,3,2,1][j]+m*2}}
const REQ={3:1,7:1,8:2,9:3};
const tier=()=>{const h=S[sel-1];return h>=13&&h<=16?h-12:0};
const say=t=>{msg=t;mt=90};
const RC=[{o:[6,4],i:[[4,1]]},{o:[12,4],i:[[6,2]]},{o:[18,1],i:[[6,4]]},{o:[19,1],i:[[3,8]],t:1},{o:[17,1],i:[[8,1],[7,1]],t:2},{o:[13,1],i:[[6,3],[12,2]],t:1},{o:[14,1],i:[[3,3],[12,2]],t:1},{o:[15,1],i:[[17,3],[12,2]],t:1},{o:[16,1],i:[[9,3],[12,2]],t:1}];
function ico(x,y,id){if(B[id])tile(x,y,id);else{g.fillStyle=IT[id].c;g.fillRect(x+4,y+4,24,24);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x+4,y+4,24,24);g.fillStyle='#3b2f20';g.font='bold 12px Georgia';g.fillText(IT[id].s,x+8,y+22)}}
function clickInvOld(){RC.forEach((r,i)=>{const y=76+i*47;if(mx>=380&&mx<=740&&my>=y&&my<=y+42){if(r.i.every(([a,c])=>inv[a]>=c)){r.i.forEach(([a,c])=>inv[a]-=c);inv[r.o[0]]+=r.o[1];say('Fabricaste '+nm(r.o[0]))}else say('Te faltan materiales')}})}
function drawUIold(){
 g.fillStyle='rgba(244,236,216,.9)';g.fillRect(0,0,118,26);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(0,0,118,26);g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText('Inventario [E]',8,18);
 if(mt>0){mt--;g.font='bold 16px Georgia';g.strokeStyle='#000';g.lineWidth=3;g.strokeText(msg,VW/2-80,60);g.fillStyle='#fff';g.fillText(msg,VW/2-80,60)}
 if(!open)return;
 g.fillStyle='rgba(244,236,216,.97)';g.fillRect(40,36,720,380);g.strokeStyle='#3b2f20';g.lineWidth=3;g.strokeRect(40,36,720,380);
 g.fillStyle='#3b2f20';g.font='bold 16px Georgia';g.fillText('Inventario',60,62);g.fillText('Crafteos (clic para fabricar)',380,62);
 let n=0;for(let id=1;id<18;id++)if(inv[id]>0){const x=60+(n%5)*60,y=80+(n/5|0)*60;ico(x,y,id);g.fillStyle='#3b2f20';g.font='bold 12px Georgia';g.fillText(inv[id],x+22,y+40);g.font='9px Georgia';g.fillText(nm(id).slice(0,9),x,y+50);n++}
 RC.forEach((r,i)=>{const y=76+i*47,ok=r.i.every(([a,c])=>inv[a]>=c);g.fillStyle=ok?'#cfe8b0':'#e4d9bf';g.fillRect(380,y,360,42);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(380,y,360,42);ico(384,y+5,r.o[0]);g.fillStyle='#3b2f20';g.font='bold 13px Georgia';g.fillText(r.o[1]+'× '+nm(r.o[0]),420,y+17);g.font='11px Georgia';g.fillText(r.i.map(([a,c])=>c+' '+nm(a)).join(' + '),420,y+34)});
}
const GX=60,GY=100;
const spos=k=>k<27?[GX+(k%9)*44,GY+(k/9|0)*46]:[GX+(k-27)*44,288];
const slotAt=()=>{for(let k=0;k<31;k++){const [x,y]=spos(k);if(mx>=x&&mx<x+40&&my>=y&&my<y+42)return k}return -1};
function clickInvOld2(){const k=slotAt();if(k>=0&&S[k])drag=k;RC.forEach((r,i)=>{const y=76+i*47;if(mx>=470&&mx<=740&&my>=y&&my<=y+42){if(r.i.every(([a,c])=>inv[a]>=c)){r.i.forEach(([a,c])=>inv[a]-=c);inv[r.o[0]]+=r.o[1];say('Fabricaste '+nm(r.o[0]))}else say('Te faltan materiales')}})}
function dropInv(){if(drag<0)return;const k=slotAt();if(k>=0&&k!=drag&&okS(k,S[drag])&&okS(drag,S[k])){const t=S[drag];S[drag]=S[k];S[k]=t}drag=-1}
function held(px,py){const id=S[sel-1];if(!id)return;
 g.save();g.translate(px+P.w*T/2+P.face*10,py+34);g.scale(P.face,1);
 if((mdown&&!open)||swg>0)g.rotate(Math.sin(performance.now()/60)*.7);
 if(id>=12&&id<=16){g.strokeStyle='#6b4423';g.lineWidth=3;g.beginPath();g.moveTo(-2,6);g.lineTo(10,-12);g.stroke();
  if(id>12){g.fillStyle=IT[id].c;g.strokeStyle='#3b2f20';g.lineWidth=2;g.beginPath();g.moveTo(2,-14);g.quadraticCurveTo(12,-20,20,-8);g.lineTo(16,-8);g.quadraticCurveTo(12,-13,6,-9);g.closePath();g.fill();g.stroke()}}
 else if(id>=40&&id<=52)toolDraw(id);
 else{g.scale(.45,.45);ico(-16,-30,id)}
 g.restore()}
function drawUIold2(){
 g.fillStyle='rgba(244,236,216,.9)';g.fillRect(0,0,118,26);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(0,0,118,26);g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText('Inventario [E]',8,18);
 if(mt>0){mt--;g.font='bold 16px Georgia';g.strokeStyle='#000';g.lineWidth=3;g.strokeText(msg,VW/2-80,60);g.fillStyle='#fff';g.fillText(msg,VW/2-80,60)}
 if(!open)return;
 g.fillStyle='rgba(244,236,216,.97)';g.fillRect(40,36,720,380);g.strokeStyle='#3b2f20';g.lineWidth=3;g.strokeRect(40,36,720,380);
 g.fillStyle='#3b2f20';g.font='bold 16px Georgia';g.fillText('Inventario (arrastra para mover)',60,62);g.fillText('Crafteos',470,62);
 g.font='11px Georgia';g.fillText('Barra rápida (teclas 1-9)',60,92);
 for(let k=0;k<27;k++){const x=GX+(k%9)*44,y=GY+(k/9|0)*46,id=S[k];g.fillStyle='#e4d9bf';g.fillRect(x,y,40,42);g.strokeStyle=k==sel-1?'#d23':k<9?'#8a5a2b':'#3b2f20';g.lineWidth=k==sel-1?3:2;g.strokeRect(x,y,40,42);
  if(id&&k!=drag){ico(x+4,y+2,id);g.fillStyle='#3b2f20';g.font='bold 12px Georgia';g.fillText(inv[id],x+26,y+40)}}
 const h=slotAt();if(h>=0&&S[h]&&drag<0){g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText(nm(S[h]),60,270)}
 RC.forEach((r,i)=>{const y=76+i*47,ok=r.i.every(([a,c])=>inv[a]>=c);g.fillStyle=ok?'#cfe8b0':'#e4d9bf';g.fillRect(470,y,270,42);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(470,y,270,42);ico(474,y+5,r.o[0]);g.fillStyle='#3b2f20';g.font='bold 13px Georgia';g.fillText(r.o[1]+'× '+nm(r.o[0]),510,y+17);g.font='11px Georgia';g.fillText(r.i.map(([a,c])=>c+' '+nm(a)).join(' + '),510,y+34)});
 if(drag>=0&&S[drag])ico(mx-16,my-16,S[drag]);
}
function nearT(n){const a=Math.floor(P.x+P.w/2),b=Math.floor(P.y+P.h/2);for(let i=-4;i<=4;i++)for(let j=-3;j<=3;j++)if(get(a+i,b+j)==(n||18))return true;return false}
function clickInv(){if(cre){const h=crAt();if(h>=0){const id=CRL[h],p=S.indexOf(id);if(p>=0)S[p]=0;S[sel-1]=id;inv[id]=999;say(nm(id))}}if(my>=42&&my<=64){if(mx>=470&&mx<=516)rtab=0;else if(mx>=520&&mx<=572)rtab=1;else if(mx>=576&&mx<=622)rtab=2;else if(mx>=626&&mx<=672)rtab=3;else if(mx>=676&&mx<=740)rtab=4}const k=slotAt();if(k>=0&&S[k])drag=k;RL().forEach((r,i)=>{const y=72+i*36;if(mx>=470&&mx<=740&&my>=y&&my<=y+34){if(!r.i.every(([a,c])=>inv[a]>=c))say('Te faltan materiales');else if(r.t&&!nearT(r.t==2?19:18))say(r.t==2?'Necesitas un horno cerca':'Necesitas una mesa de crafteo cerca');else{r.i.forEach(([a,c])=>inv[a]-=c);inv[r.o[0]]+=r.o[1];say('Fabricaste '+nm(r.o[0]))}}})}
function drawUI(){
 g.fillStyle='rgba(244,236,216,.9)';g.fillRect(0,0,118,26);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(0,0,118,26);g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText('Inventario [E]',8,18);
 if(mt>0){mt--;g.font='bold 16px Georgia';g.strokeStyle='#000';g.lineWidth=3;g.strokeText(msg,VW/2-80,60);g.fillStyle='#fff';g.fillText(msg,VW/2-80,60)}
 if(!open)return;
 g.fillStyle='rgba(244,236,216,.97)';g.fillRect(40,36,720,380);g.strokeStyle='#3b2f20';g.lineWidth=3;g.strokeRect(40,36,720,380);
 g.fillStyle='#3b2f20';g.font='bold 16px Georgia';g.fillText('Inventario (arrastra para mover)',60,62);g.fillText('Crafteos',470,62);
 g.font='11px Georgia';g.fillText('Barra rápida (teclas 1-9)',60,92);
 for(let k=0;k<27;k++){const x=GX+(k%9)*44,y=GY+(k/9|0)*46,id=S[k];g.fillStyle='#e4d9bf';g.fillRect(x,y,40,42);g.strokeStyle=k==sel-1?'#d23':k<9?'#8a5a2b':'#3b2f20';g.lineWidth=k==sel-1?3:2;g.strokeRect(x,y,40,42);
  if(id&&k!=drag){ico(x+4,y+2,id);g.fillStyle='#3b2f20';g.font='bold 12px Georgia';g.fillText(inv[id],x+26,y+40)}}
 const h=slotAt();if(h>=0&&S[h]&&drag<0){g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText(nm(S[h]),60,270)}
 g.fillStyle='#3b2f20';g.font='11px Georgia';g.fillText('Los marcados con • mesa o • horno necesitan ese bloque',60,360);g.fillText('a menos de 4 bloques. En naranja: te falta el bloque.',60,376);
 [['Base',470,46],['Armad.',520,52],['Armas',576,46],['Otros',626,46],['Iron M.',676,64]].forEach(([t,x,w],i)=>{g.fillStyle=rtab==i?'#cfe8b0':'#e4d9bf';g.fillRect(x,42,w,22);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x,42,w,22);g.fillStyle='#3b2f20';g.font='12px Georgia';g.fillText(t,x+6,57)});
 g.fillStyle='#3b2f20';g.font='11px Georgia';g.fillText('Armadura (arrastra aquí)',60,282);g.fillText('Defensa: '+def()+'  ('+def()*5+'% menos daño)',250,312);
 for(let j=0;j<4;j++){const k=27+j,x=GX+j*44,y=288,id=S[k];g.fillStyle='#e4d9bf';g.fillRect(x,y,40,42);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x,y,40,42);if(id&&k!=drag)ico(x+4,y+2,id);else if(!id){g.fillStyle='rgba(59,47,32,.35)';g.font='12px Georgia';g.fillText(AS[j],x+12,y+26)}}
 if(cre){g.fillStyle='#f4ecd8';g.fillRect(462,40,290,370);crDraw()}
 const nt=nearT(18),nf=nearT(19);
 RL().forEach((r,i)=>{const y=72+i*36,has=r.i.every(([a,c])=>inv[a]>=c);g.fillStyle=has&&(!r.t||(r.t==2?nf:nt))?'#cfe8b0':has?'#f0d9a0':'#e4d9bf';g.fillRect(470,y,270,34);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(470,y,270,34);ico(474,y+1,r.o[0]);g.fillStyle='#3b2f20';g.font='bold 13px Georgia';g.fillText(r.o[1]+'× '+nm(r.o[0])+(r.t?(r.t==2?'  • horno':'  • mesa'):''),510,y+15);g.font='11px Georgia';g.fillText(r.i.map(([a,c])=>c+' '+nm(a)).join(' + '),510,y+30)});
 if(drag>=0&&S[drag])ico(mx-16,my-16,S[drag]);
}
function mine(){
 if(open||ske||S[sel-1]==52||mdown!=1||my>=VH-50)return;
 const tx=Math.floor((mx+cam.x)/T),ty=Math.floor((my+cam.y)/T),k=get(tx,ty);
 if(!k||(k>=10&&k<18)||ty>=H-1||Math.hypot(tx+.5-P.x-P.w/2,ty+.5-P.y-P.h/2)>=5.5){mp=0;return}
 if(mtx!=tx||mty!=ty){mtx=tx;mty=ty;mp=0}
 if(!cre&&tier()<(REQ[k]||0)){say('Necesitas un pico mejor en la mano');return}
 mp+=cre?9999:spd(k);
 if(mp>=HD[k]){if(!cre)drop(tx,ty,k==31?30:k==33?32:k);brk(tx,ty,k);mp=0}
}
const RCA=[20,21,22,23].map((id,j)=>({o:[id,1],i:[[17,[3,5,4,2][j]]],t:1})).concat([24,25,26,27].map((id,j)=>({o:[id,1],i:[[9,[3,5,4,2][j]]],t:1})));
const RCB=[{o:[30,1],i:[[6,6]],t:1},{o:[32,2],i:[[6,4]],t:1},{o:[34,4],i:[[35,2],[7,1]],t:2},{o:[37,1],i:[[36,1],[7,1]],t:2}];
let rtab=0;const RL=()=>cre?[]:[RC,RCA,RCW,RCB.concat(RCS),RCI][rtab];
const okS=(k,id)=>k<27||!id||(ARM[id]&&ARM[id].s==k-27);
const def=()=>{let d=0;for(let j=0;j<4;j++){const a=ARM[S[27+j]];if(a)d+=a.d}return d};
function hurt(n){if(n<=0||cre)return;n=Math.max(1,Math.round(n*(1-.05*def())));HP-=n;hurtT=15;rg=0;if(HP<=0){HP=20;P.x=70-OX;P.y=hgt(70-OX)-3;P.vx=0;P.vy=0;P.fs=null;say('¡Moriste! Reapareces en el inicio')}}
function armorDraw(px,py){const w=P.w*T;for(let j=0;j<4;j++){const id=S[27+j];if(!id)continue;const im=IMS.has(id),nn=(id>=57&&id<=59)||id==38;g.fillStyle=im?(nn?'#c4161e':'#b3141b'):id>=24?'#4ee3e3':'#cfd3d8';g.strokeStyle='#3b2f20';g.lineWidth=1.5;const r=[[px-1,py-3,w+2,9],[px,py+20,w,22],[px,py+42,w,8],[px-1,py+50,w+2,5]][j];g.fillRect(...r);g.strokeRect(...r);if(im)ironExtra(nn,j,r)}}
function drawHUD(){if(hurtT>0){hurtT--;g.fillStyle='rgba(200,0,0,.25)';g.fillRect(0,0,VW,VH)}g.font='18px Georgia';if(!cre)for(let i=0;i<10;i++){g.fillStyle=HP>=2*i+2?'#d22':HP==2*i+1?'#e88':'rgba(60,40,30,.45)';g.fillText('♥',VW-208+i*20,24)}const d=def();if(d){g.font='12px Georgia';g.fillStyle='#3b2f20';g.fillText('Defensa '+d,VW-208,42)}}
const MN=['madera','piedra','hierro','diamante'],MC=['#d2a65e','#9a9a9a','#cfd3d8','#4ee3e3'],MI=[6,3,17,9];
for(let t=0;t<4;t++){IT[40+t]={n:'Espada de '+MN[t],c:MC[t],s:'E'+'mphd'[t]};IT[44+t]={n:'Hacha de '+MN[t],c:MC[t],s:'A'+'mphd'[t]};IT[48+t]={n:'Pala de '+MN[t],c:MC[t],s:'L'+'mphd'[t]}}
IT[52]={n:'Doble espada',c:'#a855f7',s:'DE'};
const RCW=[0,1,2,3].map(t=>({o:[40+t,1],i:[[MI[t],2],[12,1]],t:1})).concat([0,1,2,3].map(t=>({o:[44+t,1],i:[[MI[t],3],[12,2]],t:1})),[{o:[52,1],i:[[43,2],[9,3]],t:1}]);
const RCS=[0,1,2,3].map(t=>({o:[48+t,1],i:[[MI[t],1],[12,2]],t:1}));
const MON=[],ARR=[],EX=[];let mkc=0,dayT=0;
const nl=()=>Math.max(0,Math.min(1,-1.4*Math.cos(dayT/14400*6.2832)-.2));
function nightDraw(){const d=Math.max(0,Math.min(1,(P.y-hgt(P.x|0)-4)/14)),a=Math.max(nl()*.5,d*.45);if(a>.01){g.fillStyle='rgba(8,10,40,'+a+')';g.fillRect(0,0,VW,VH)}}
function monSpawn(){const x=Math.floor(P.x+(Math.random()<.5?-1:1)*(14+Math.random()*16));if(x<2||x>=W-2)return;
 let y=-1;const h=hgt(x);
 if(nl()>.5&&Math.random()<.5&&sol(x,h)&&get(x,h-1)==0&&get(x,h-2)==0)y=h-1;
 if(y<0)for(let k=0;k<15;k++){const yy=h+6+(Math.random()*(H-h-9)|0);if(get(x,yy)==0&&get(x,yy-1)==0&&sol(x,yy+1)){y=yy;break}}
 if(y<0)return;
 const t=Math.random()*3|0,[w,hh,hp]=[[.7,1.7,20],[.7,1.7,16],[.7,1.4,14]][t];
 if(hitR(x+.15,y+1-hh-.01,w,hh))return;
 MON.push({mon:1,t,x:x+.15,y:y+1-hh-.01,w,h:hh,hp,vx:0,vy:0,face:1,gnd:false,cd:30,hurt:0,fuse:0,kb:0})}
function mphys(m,sp,dir){m.vx=dir*sp+m.kb;m.kb*=.85;if(Math.abs(m.kb)<.01)m.kb=0;if(dir)m.face=dir;
 m.vy=Math.min(m.vy+.02,.5);
 const q=get(Math.floor(m.x+m.w/2),Math.floor(m.y+m.h*.6));
 if(q==11){m.hp=0;return}
 if(q==10)m.vy=-.04;
 const nx=m.x+m.vx;if(!hitR(nx,m.y,m.w,m.h))m.x=nx;else if(m.gnd)m.vy=-.27;
 m.x=Math.max(0,Math.min(W-m.w,m.x));
 const ny=m.y+m.vy;m.gnd=false;if(!hitR(m.x,ny,m.w,m.h))m.y=ny;else{if(m.vy>0)m.gnd=true;m.vy=0}}
function monDie(a){const id=a.t==0?36:a.t==1?12:7,n=a.t==0?(Math.random()<.6?1:0):1+(Math.random()<.5?1:0);for(let k=0;k<n;k++)drop(Math.floor(a.x+a.w/2),Math.floor(a.y+a.h/2),id);const i=MON.indexOf(a);if(i>=0)MON.splice(i,1)}
function boom(m){const cx=m.x+m.w/2,cy=m.y+m.h/2;EX.push({x:cx,y:cy,t:18});netBoom(cx,cy);
 const pd=Math.hypot(P.x+P.w/2-cx,P.y+P.h/2-cy);if(pd<5)hurt(Math.max(1,Math.round(10*(1-pd/5))));
 for(let i=-3;i<=3;i++)for(let j=-3;j<=3;j++)if(i*i+j*j<=7){const tx=Math.floor(cx)+i,ty=Math.floor(cy)+j,k=get(tx,ty);if(k&&k!=10&&k!=11&&ty<H-1&&tx>=0&&tx<W)set(tx,ty,0)}}
function monTick(){dayT++;const nlv=nl();
 if(++mkc%150==0&&MON.length<7)monSpawn();
 for(let i=MON.length-1;i>=0;i--){const m=MON[i];if(m.hurt>0)m.hurt--;if(m.cd>0)m.cd--;
  const tp=netTgt(m),dx=tp.x+P.w/2-(m.x+m.w/2),dy=tp.y+P.h/2-(m.y+m.h/2),dist=Math.hypot(dx,dy),sg=dx>=0?1:-1;
  if(dist>48){MON.splice(i,1);continue}
  if(nlv<.5&&m.y<hgt(Math.floor(m.x))+2&&dayT%30==0){m.hp-=2;m.hurt=10}
  let dir=0,sp=.055;
  if(m.t==0){if(dist<16)dir=sg;if(dist<1.1&&m.cd<=0){if(tp===P){if(!P.ball)hurt(3);P.vy=-.1}else netHurt(tp,3);m.cd=50}}
  else if(m.t==1){m.face=sg;sp=.04;if(dist<4)dir=-sg;else if(dist>8&&dist<16)dir=sg;if(dist<14&&Math.abs(dy)<4&&m.cd<=0){ARR.push({x:m.x+m.w/2,y:m.y+.5,vx:sg*.35,vy:-.01,t:0});m.cd=90}}
  else{if(dist<14)dir=sg;sp=.05;if(dist<2.2)m.fuse++;else m.fuse=Math.max(0,m.fuse-1);if(m.fuse>=50){boom(m);MON.splice(i,1);continue}}
  mphys(m,m.t==2&&m.fuse>0?0:sp,dir);
  if(m.hp<=0)monDie(m)}
 for(let i=ARR.length-1;i>=0;i--){const a=ARR[i];a.x+=a.vx;a.y+=a.vy;a.vy+=.004;a.t++;if(sol(a.x,a.y)||a.t>120){ARR.splice(i,1);continue}if(a.x>P.x&&a.x<P.x+P.w&&a.y>P.y&&a.y<P.y+P.h){hurt(3);ARR.splice(i,1)}else{const rp=netArrowHit(a);if(rp){netHurt(rp,3);ARR.splice(i,1)}}}
 for(let i=EX.length-1;i>=0;i--)if(--EX[i].t<=0)EX.splice(i,1)}
function drawMon(m){const px=m.x*T-cam.x,py=m.y*T-cam.y,w=m.w*T,h=m.h*T;g.strokeStyle='#1d2a14';g.lineWidth=1.5;
 const fl=m.hurt>0?'#e66':(m.t==2&&m.fuse>0&&Math.floor(m.fuse/5)%2?'#fff':null);
 const C=[['#5b9a4a','#3a8fa8','#3b3b8a'],['#e8e4d8','#d8d4c4','#bdb9a8'],['#6bbf59','#5aa84a','#4a9a3a']][m.t];
 g.fillStyle=fl||C[2];g.fillRect(px+2,py+h*.62,w/2-3,h*.38);g.fillRect(px+w/2+1,py+h*.62,w/2-3,h*.38);
 g.fillStyle=fl||C[1];g.fillRect(px+2,py+h*.3,w-4,h*.34);g.strokeRect(px+2,py+h*.3,w-4,h*.34);
 if(m.t<2){g.fillStyle=fl||C[0];g.fillRect(m.face>0?px+w-4:px-10,py+h*.32,14,m.t==0?6:4)}
 g.fillStyle=fl||C[0];g.fillRect(px,py,w,h*.3);g.strokeRect(px,py,w,h*.3);
 g.fillStyle=m.t==2?'#1d2a14':'#c22';g.fillRect(px+(m.face>0?w-10:3),py+h*.1,4,4);
 if(m.t==2){g.fillRect(px+3,py+h*.1,4,4);g.fillRect(px+w/2-3,py+h*.17,6,6)}}
function drawArr(){ARR.forEach(a=>{g.strokeStyle='#6b4423';g.lineWidth=2;g.beginPath();g.moveTo(a.x*T-cam.x,a.y*T-cam.y);g.lineTo(a.x*T-cam.x-a.vx*40,a.y*T-cam.y-a.vy*40);g.stroke()});
 EX.forEach(e=>{g.fillStyle='rgba(255,200,80,'+e.t/18+')';g.beginPath();g.arc(e.x*T-cam.x,e.y*T-cam.y,(18-e.t)*5+20,0,7);g.fill()})}
let cre=0,invSave=[],Ssave=[];
const CRL=[1,2,3,4,5,6,7,8,9,18,19,30,32,34,35,12,13,14,15,16,17,36,37,40,41,42,43,44,45,46,47,48,49,50,51,52,20,21,22,23,24,25,26,27];
const crPos=i=>[470+(i%7)*38,80+(i/7|0)*40];
const crAt=()=>{for(let i=0;i<CRL.length;i++){const [x,y]=crPos(i);if(mx>=x&&mx<x+36&&my>=y&&my<y+38)return i}return -1};
const dec=it=>{if(!cre)inv[it]--};
function crDraw(){g.fillStyle='#3b2f20';g.font='bold 14px Georgia';g.fillText('Modo creativo: elige un objeto',470,62);
 CRL.forEach((id,i)=>{const [x,y]=crPos(i);g.fillStyle='#e4d9bf';g.fillRect(x,y,36,38);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x,y,36,38);ico(x+2,y+3,id)});
 const h=crAt();g.fillStyle='#3b2f20';g.font='13px Georgia';if(h>=0)g.fillText(nm(CRL[h]),470,424);g.font='11px Georgia';g.fillText('F: volar · W/Espacio sube · S baja',470,440)}
document.getElementById('crb').onclick=function(){if(!cre){invSave=inv.slice();Ssave=S.slice();cre=1;say('Modo creativo (F: volar)')}else{cre=0;P.fly=0;{const ni=invSave.slice(),ns=S.slice();for(let id=1;id<ni.length;id++)if(inv[id]>=999)ni[id]=Math.max(ni[id]||0,B[id]?64:1);Ssave.forEach(id=>{if(id&&!ns.includes(id)){const e=ns.findIndex((v,k)=>k<27&&!v);if(e>=0)ns[e]=id}});inv.splice(0,inv.length,...ni);S.splice(0,S.length,...ns)}say('Modo supervivencia')}this.textContent=cre?'Creativo':'Supervivencia'};
let cdn=0,swg=0,jp=false;const WV=[],SL=[],HK=[];
function hook(){cdn=90;swg=12;HK.push({x:P.x+P.w/2+P.face*.6,y:P.y+.8,vx:P.face*.6,f:P.face,t:0,tg:null,back:0})}
function hkTick(){for(let i=HK.length-1;i>=0;i--){const h=HK[i];h.t++;const px=P.x+P.w/2,py=P.y+.8;
  if(h.tg){const a=h.tg;if(a.hp<=0||(!ANI.includes(a)&&!MON.includes(a))||h.t>120){HK.splice(i,1);continue}
   const dx=px-(a.x+a.w/2);if(Math.abs(dx)<1.4){HK.splice(i,1);continue}
   const nx=a.x+Math.sign(dx)*.5;if(!hitR(nx,a.y,a.w,a.h))a.x=nx;else if(a.gnd)a.vy=-.27;
   h.x=a.x+a.w/2;h.y=a.y+a.h/2;continue}
  if(h.back){const dx=px-h.x,dy=py-h.y,d=Math.hypot(dx,dy);if(d<1){HK.splice(i,1);continue}h.x+=dx/d*.8;h.y+=dy/d*.8;continue}
  h.x+=h.vx;if(sol(h.x,h.y)||h.t>24){h.back=1;continue}
  for(const a of ANI.concat(MON)){if(h.x>a.x-.2&&h.x<a.x+a.w+.2&&h.y>a.y-.3&&h.y<a.y+a.h+.3){h.tg=a;h.t=0;hitAni(a,4);break}}}}
function drawHK(){HK.forEach(h=>{const sx=h.x*T-cam.x,sy=h.y*T-cam.y,ox=(P.x+P.w/2)*T-cam.x,oy=(P.y+.8)*T-cam.y;g.save();g.strokeStyle='rgba(168,85,247,.8)';g.lineWidth=2;g.shadowColor='#a855f7';g.shadowBlur=8;g.beginPath();g.moveTo(ox,oy);g.lineTo(sx,sy);g.stroke();g.translate(sx,sy);g.rotate(h.t*.5);g.strokeStyle='#3b2f20';g.lineWidth=7;g.beginPath();g.moveTo(-11,0);g.lineTo(11,0);g.stroke();g.strokeStyle='#4ee3e3';g.lineWidth=4;g.beginPath();g.moveTo(-11,0);g.lineTo(11,0);g.stroke();g.restore()})}
function wdmg(h){return h>=13&&h<=16?h-11:h>=40&&h<=43?h-36:h>=44&&h<=47?h-41:h>=48&&h<=51?h-46:h==52?10:1}
function sweep(){cdn=18;swg=12;SL.push({t:12,f:P.face});for(const a of ANI.concat(MON)){const dx=a.x+a.w/2-(P.x+P.w/2),dy=a.y+a.h/2-(P.y+P.h/2);if(Math.abs(dy)<2.2&&dx*P.face>-.5&&Math.abs(dx)<3.5)hitAni(a,10)}}
function wave(){cdn=50;swg=12;WV.push({x:P.x+P.w/2+P.face*.6,y:P.y+.8,vx:P.face*.45,t:0,h:[],f:P.face})}
function fxTick(){sonicTick();hkTick();rbTick();jdTick();spkTick();if(cdn>0)cdn--;if(swg>0)swg--;for(let i=SL.length-1;i>=0;i--)if(--SL[i].t<=0)SL.splice(i,1);
 for(let i=WV.length-1;i>=0;i--){const v=WV[i];v.x+=v.vx;v.t++;if(sol(v.x,v.y)||v.t>40){WV.splice(i,1);continue}
  for(const a of ANI.concat(MON))if(!v.h.includes(a)&&v.x>a.x-.3&&v.x<a.x+a.w+.3&&v.y>a.y-.5&&v.y<a.y+a.h+.5){v.h.push(a);hitAni(a,12)}}}
function drawFX(){drawHK();rbDraw();jdDraw();SL.forEach(s=>{const cx=(P.x+P.w/2+s.f*1.4)*T-cam.x,cy=(P.y+.9)*T-cam.y,a0=s.f>0?-1.1:Math.PI-1.1,a1=s.f>0?1.1:Math.PI+1.1;g.strokeStyle='rgba(255,255,255,'+s.t/12+')';g.lineWidth=5;g.beginPath();g.arc(cx,cy,34,a0,a1);g.stroke()});
 WV.forEach(v=>{const x=v.x*T-cam.x,y=v.y*T-cam.y;g.save();g.shadowColor='#a855f7';g.shadowBlur=14;g.fillStyle='rgba(168,85,247,.85)';g.beginPath();g.ellipse(x,y,9,24,0,0,7);g.fill();g.fillStyle='rgba(78,227,227,.9)';g.beginPath();g.ellipse(x+v.f*3,y,4,16,0,0,7);g.fill();g.restore()})}
function toolDraw(id){const c=IT[id].c;
 const ln=(w,col,x1,y1,x2,y2)=>{g.strokeStyle=col;g.lineWidth=w;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke()};
 const sw=col=>{ln(7,'#3b2f20',6,-8,20,-26);ln(4,col,6,-8,20,-26);ln(3,'#6b4423',-2,6,6,-6);ln(3,'#3b2f20',2,-8,10,-4)};
 if(id<44)sw(c);
 else if(id<52){ln(3,'#6b4423',-2,6,10,-12);g.fillStyle=c;g.strokeStyle='#3b2f20';g.lineWidth=2;g.beginPath();if(id<48){g.moveTo(6,-10);g.lineTo(20,-14);g.lineTo(20,-2);g.lineTo(9,-4)}else g.ellipse(13,-14,5,7,.6,0,7);g.closePath();g.fill();g.stroke()}
 else{g.shadowColor='#a855f7';g.shadowBlur=10;g.save();g.rotate(-.35);sw('#4ee3e3');g.restore();g.save();g.rotate(.35);sw('#a855f7');g.restore();g.shadowBlur=0}}
let ske=0,skn=[];
const SKC=document.createElement('canvas');SKC.width=8;SKC.height=17;
const PAL=['#f1c9a0','#c68642','#8d5524','#ffdbac','#5a3a22','#222222','#ffffff','#d22222','#e8a020','#e8e040','#48b848','#3a6fd8','#4b3b9a','#8a2be2','#f2a7b6','#6b6b6b'];
const SKD={sk:'#f1c9a0',hair:'#5a3a22',shirt:'#3a6fd8',pants:'#4b3b9a',shoe:'#2a2a2a'};
function mkSkin(o){const a=new Array(136).fill('');for(let r=0;r<17;r++)for(let c=0;c<8;c++){let v='';
 if(r<6){v=r==0||(r==1&&(c<2||c>5))?o.hair:o.sk;if(r==3&&(c==2||c==5))v='#222222';if(r==5&&(c==3||c==4))v='#a5523a'}
 else if(r<13)v=(c==0||c==7)?(r>=10?o.sk:o.shirt):o.shirt;
 else v=r==16?o.shoe:o.pants;
 a[r*8+c]=v}return a}
function skRender(){const x=SKC.getContext('2d');x.clearRect(0,0,8,17);skn.forEach((c,i)=>{if(c){x.fillStyle=c;x.fillRect(i%8,(i/8)|0,1,1)}})}
function skSave(){try{localStorage.setItem('pmskin',JSON.stringify(skn))}catch(e){}}
skn=mkSkin(SKD);
try{const s=JSON.parse(localStorage.getItem('pmskin'));if(Array.isArray(s)&&s.length==136)skn=s}catch(e){}
skRender();
document.getElementById('skb').onclick=()=>{ske=!ske;open=0};
const rnd=a=>a[Math.random()*a.length|0];
let sks=[],skMsg='',skMsgT=0;
try{const s=JSON.parse(localStorage.getItem('pmskins'));if(Array.isArray(s))sks=s.filter(o=>o&&Array.isArray(o.d)&&o.d.length==136).slice(0,8)}catch(e){}
function sksSave(){try{localStorage.setItem('pmskins',JSON.stringify(sks.map(o=>({d:o.d}))))}catch(e){skMsg='No se pudo guardar';skMsgT=150}}
function skCv(o){if(!o.cv){const c=document.createElement('canvas');c.width=8;c.height=17;const x=c.getContext('2d');o.d.forEach((col,i)=>{if(col){x.fillStyle=col;x.fillRect(i%8,(i/8)|0,1,1)}});o.cv=c}return o.cv}
const skSame=(a,b)=>a.length==b.length&&a.every((v,i)=>v===b[i]);
function skAdd(){if(sks.some(o=>skSame(o.d,skn))){skMsg='Esa skin ya está guardada';skMsgT=150;return}
 if(sks.length>=8){skMsg='Máximo 8 skins: borra una (clic der.)';skMsgT=180;return}
 sks.push({d:skn.slice()});sksSave();if(!skMsgT)skMsg='¡Skin guardada!';skMsgT=150}
function skRand(){skn=mkSkin({sk:rnd(['#f1c9a0','#c68642','#8d5524','#ffdbac','#7bc47f','#9fd0ff']),hair:rnd(['#5a3a22','#222222','#e8c040','#d22222','#8a2be2','#ffffff']),shirt:rnd(PAL),pants:rnd(PAL),shoe:rnd(['#2a2a2a','#5a3a22','#d22222','#ffffff'])});skRender();skSave()}
function skPtr(btn,drag){const gx=Math.floor((mx-80)/18),gy=Math.floor((my-90)/18);
 if(gx>=0&&gx<8&&gy>=0&&gy<17){skn[gy*8+gx]=btn==2?'':document.getElementById('pc').value;skRender();skSave();return}
 if(drag)return;
 PAL.forEach((c,i)=>{const x=470+(i%4)*40,y=90+(i/4|0)*40;if(mx>=x&&mx<x+36&&my>=y&&my<y+36)document.getElementById('pc').value=c});
 if(mx>=470&&mx<=560&&my>=310&&my<=336){skn=mkSkin(SKD);skRender();skSave()}
 if(mx>=570&&mx<=670&&my>=310&&my<=336)skRand();
 if(btn!=2&&mx>=470&&mx<=620&&my>=345&&my<=371)skAdd();
 for(let i=0;i<8;i++){const x=640+(i%4)*27,y=90+(i/4|0)*62;if(mx>=x&&mx<x+26&&my>=y&&my<y+58&&sks[i]){
  if(btn==2){sks.splice(i,1);sksSave();skMsg='Skin borrada';skMsgT=120}
  else{skn=sks[i].d.slice();skRender();skSave();skMsg='Skin cargada';skMsgT=120}
  break}}
 if(mx>=640&&mx<=740&&my>=44&&my<=68){ske=0;skSave()}}
function skinDraw(px,py){const w=P.w*T,h=P.h*T;g.save();g.imageSmoothingEnabled=false;
 if(P.face<0){g.translate(px+w,py);g.scale(-1,1);g.drawImage(SKC,0,0,8,17,0,0,w,h)}else g.drawImage(SKC,0,0,8,17,px,py,w,h);g.restore()}
function drawSkin(){
 g.fillStyle='rgba(244,236,216,.98)';g.fillRect(40,36,720,380);g.strokeStyle='#3b2f20';g.lineWidth=3;g.strokeRect(40,36,720,380);
 g.fillStyle='#3b2f20';g.font='bold 16px Georgia';g.fillText('Editor de skin',60,62);g.font='12px Georgia';g.fillText('Clic: pintar · Clic derecho: borrar',60,80);
 for(let i=0;i<136;i++){const x=80+(i%8)*18,y=90+(i/8|0)*18;g.fillStyle=skn[i]||((i%8+(i/8|0))%2?'#e4d9bf':'#d8ccae');g.fillRect(x,y,18,18);g.strokeStyle='rgba(59,47,32,.25)';g.lineWidth=1;g.strokeRect(x,y,18,18)}
 g.save();g.imageSmoothingEnabled=false;g.drawImage(SKC,0,0,8,17,300,90,112,238);g.restore();g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(300,90,112,238);
 g.fillStyle='#3b2f20';g.font='12px Georgia';g.fillText('Vista previa',300,82);g.fillText('Paleta',470,82);
 PAL.forEach((c,i)=>{const x=470+(i%4)*40,y=90+(i/4|0)*40;g.fillStyle=c;g.fillRect(x,y,36,36);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x,y,36,36)});
 g.fillStyle='#3b2f20';g.fillText('Color actual (o usa el selector de arriba)',470,266);g.fillStyle=document.getElementById('pc').value;g.fillRect(470,274,60,22);g.strokeRect(470,274,60,22);
 const bt=(x,y,w,h,t)=>{g.fillStyle='#e4d9bf';g.fillRect(x,y,w,h);g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(x,y,w,h);g.fillStyle='#3b2f20';g.font='13px Georgia';g.fillText(t,x+8,y+h*.65)};
 bt(470,310,90,26,'Reiniciar');bt(570,310,100,26,'Aleatoria');bt(640,44,100,24,'Cerrar');
 bt(470,345,150,26,'💾 Guardar skin');
 g.fillStyle='#3b2f20';g.font='12px Georgia';g.fillText('Mis skins ('+sks.length+'/8)',640,82);
 for(let i=0;i<8;i++){const x=640+(i%4)*27,y=90+(i/4|0)*62,o=sks[i];
  g.fillStyle='#e4d9bf';g.fillRect(x,y,26,58);g.strokeStyle=o&&skSame(o.d,skn)?'#d22222':'#3b2f20';g.lineWidth=o&&skSame(o.d,skn)?3:1;g.strokeRect(x,y,26,58);
  if(o){g.save();g.imageSmoothingEnabled=false;g.drawImage(skCv(o),0,0,8,17,x+1,y+3,24,51);g.restore()}}
 g.fillStyle='#3b2f20';g.font='11px Georgia';g.fillText('Clic: cargar',640,228);g.fillText('Clic der.: borrar',640,242);
 if(skMsgT>0){skMsgT--;g.fillStyle='#2e7d32';g.font='bold 13px Georgia';g.fillText(skMsg,470,392)}
}
const ANI=[];let ak=0,ani0=0;
const hitR=(x,y,w,h)=>{for(let i=Math.floor(x);i<=Math.floor(x+w);i++)for(let j=Math.floor(y);j<=Math.floor(y+h);j++)if(sol(i+.5,j+.5))return true;return false};
function spawnAni(x){x=x|0;if(x<2||x>=W-2)return;const h=hgt(x);if(get(x,h)!=1||get(x,h-1)!=0||get(x,h-2)!=0)return;const t=Math.random()*3|0,[w,hh,hp]=[[1.2,1,10],[.9,.75,8],[1.1,.95,8]][t];if(hitR(x+.1,h-hh-.05,w,hh))return;ANI.push({x:x+.1,y:h-hh-.05,w,h:hh,hp,t,vx:0,vy:0,dir:0,tmr:30,face:1,hurt:0,flee:0,gnd:false})}
function aniTick(){
 if(!ani0){ani0=1;for(let i=0;i<80&&ANI.length<14;i++)spawnAni(Math.random()*W)}
 if(++ak%600==0&&ANI.length<10){const x=Math.floor(P.x+(Math.random()-.5)*80);if(Math.abs(x-P.x)>20)spawnAni(x)}
 for(let i=ANI.length-1;i>=0;i--){const a=ANI[i];if(netFar(a.x)){ANI.splice(i,1);continue}
  if(a.hurt>0)a.hurt--;if(a.flee>0)a.flee--;
  if(--a.tmr<=0){a.dir=Math.random()<.35?0:Math.random()<.5?-1:1;a.tmr=60+(Math.random()*140|0)}
  let sp=.035;if(a.flee>0){a.dir=a.x+a.w/2<P.x+P.w/2?-1:1;sp=.09}
  a.vx=a.dir*sp;if(a.dir)a.face=a.dir;
  a.vy=Math.min(a.vy+.02,.5);
  const q=get(Math.floor(a.x+a.w/2),Math.floor(a.y+a.h*.6));
  if(q==11){ANI.splice(i,1);continue}
  if(q==10)a.vy=-.05;
  const nx=a.x+a.vx;
  if(!hitR(nx,a.y,a.w,a.h))a.x=nx;else{if(a.gnd)a.vy=-.25;if(!a.flee)a.tmr=Math.min(a.tmr,30)}
  a.x=Math.max(0,Math.min(W-a.w,a.x));
  const ny=a.y+a.vy;a.gnd=false;
  if(!hitR(a.x,ny,a.w,a.h))a.y=ny;else{if(a.vy>0)a.gnd=true;a.vy=0}
  if(a.y>H)ANI.splice(i,1)}}
function hitAni(a,dm){swg=12;const hd=S[sel-1],dmg=dm||wdmg(hd);a.hp-=dmg;a.hurt=20;a.flee=150;a.vy=-.15;a.kb=(a.x+a.w/2>P.x+P.w/2?1:-1)*.15;
 if(a.hp<=0){if(a.mon){monDie(a);return}const n=1+(Math.random()<.5?1:0);for(let k=0;k<n;k++)drop(Math.floor(a.x+a.w/2),Math.floor(a.y+a.h/2),36);ANI.splice(ANI.indexOf(a),1)}}
function drawAni(a){const px=a.x*T-cam.x,py=a.y*T-cam.y,w=a.w*T,h=a.h*T,C=[['#f2efe6','#5a3a22'],['#f2a7b6','#d98a9b'],['#f4f4f4','#3b3b3b']][a.t];
 g.strokeStyle='#3b2f20';g.lineWidth=1.5;g.fillStyle=a.hurt>0?'#e66':C[0];
 g.fillRect(px,py+h*.15,w,h*.6);g.strokeRect(px,py+h*.15,w,h*.6);
 g.fillStyle=C[1];g.fillRect(px+3,py+h*.75,5,h*.25);g.fillRect(px+w-8,py+h*.75,5,h*.25);
 if(a.t==0)g.fillRect(px+w*.3,py+h*.2,w*.25,h*.25);
 const hx=a.face>0?px+w-3:px-h*.35+3,hs=h*.42;
 g.fillStyle=a.t==2?'#3b3b3b':a.hurt>0?'#e66':C[0];g.fillRect(hx,py+h*.1,hs,hs);g.strokeRect(hx,py+h*.1,hs,hs);
 g.fillStyle='#fff';g.fillRect(hx+(a.face>0?hs-7:3),py+h*.1+5,3,3);
 if(a.t==1){g.fillStyle='#e07a8c';g.fillRect(hx+(a.face>0?hs-4:-2),py+h*.1+hs*.45,6,6)}}
let fk=0;
function flowTick(){if(++fk%8)return;const add=[],rem=[],lm=fk%24==0,xa=Math.max(0,Math.floor(P.x)-70),xb=Math.min(W,Math.floor(P.x)+70);
 for(let y=0;y<H;y++)for(let x=xa;x<xb;x++){const i=y*W+x,t=w[i];if(t!=10&&t!=11)continue;if(t==11&&!lm)continue;
  const l=LV[i]||9,d=t==11?2:1;
  if(l<9){let fed=get(x,y-1)==t;
   if(!fed&&l<8)for(const dx of [-1,1])if(get(x+dx,y)==t&&get(x+dx,y+1)!=0){const nl=LV[i+dx]||9;if(Math.min(nl,8)-d==l)fed=true}
   if(!fed){rem.push(i);continue}}
  const b=get(x,y+1);
  if(b==0)add.push([x,y+1,t,8]);
  else if(b!=t){const nl=Math.min(l,8)-d;if(nl>=1)for(const dx of [-1,1])if(get(x+dx,y)==0)add.push([x+dx,y,t,nl])}}
 rem.forEach(i=>{if(w[i]==10||w[i]==11)set(i%W,(i/W)|0,0)});
 add.forEach(([x,y,t,lv])=>{if(get(x,y)!=0)return;const o=t==10?11:10;if(get(x+1,y)==o||get(x-1,y)==o||get(x,y-1)==o||get(x,y+1)==o)set(x,y,3);else{set(x,y,t);LV[y*W+x]=lv}})}
let sk=0;
function sandTick(){if(++sk%5)return;const xa=Math.max(0,Math.floor(P.x)-70),xb=Math.min(W,Math.floor(P.x)+70);for(let y=H-2;y>=0;y--)for(let x=xa;x<xb;x++)if(get(x,y)==35){const b=get(x,y+1);if((b==0||b==10||b==11)&&!(x+1>P.x&&x<P.x+P.w&&y+2>P.y&&y+1<P.y+P.h)){set(x,y+1,35);set(x,y,b)}}}
const isOp=q=>q>=30&&q<=33;
function tgl(tx,ty){const q=get(tx,ty);
 if(q==32||q==33){set(tx,ty,q==32?33:32);if(hit(P.x,P.y))set(tx,ty,q);return}
 let y0=ty;while(get(tx,y0-1)==30||get(tx,y0-1)==31)y0--;
 const cs=[];for(let y=y0;get(tx,y)==30||get(tx,y)==31;y++)cs.push(y);
 const nq=q==30?31:30;cs.forEach(y=>set(tx,y,nq));if(hit(P.x,P.y))cs.forEach(y=>set(tx,y,q))}
function brk(tx,ty,k){if(k==30||k==31){let y0=ty;while(get(tx,y0-1)==30||get(tx,y0-1)==31)y0--;for(let y=y0;get(tx,y)==30||get(tx,y)==31;y++)set(tx,y,0)}else set(tx,ty,0)}
const DR=[];
const sol=(x,y)=>{const q=get(Math.floor(x),Math.floor(y));return q&&q!=4&&q!=5&&(q<10||q>17&&q!=31&&q!=33)};
function drop(tx,ty,id){DR.push({x:tx+.5,y:ty+.5,vx:(Math.random()-.5)*.1,vy:-.12,id,t:0});if(DR.length>200)DR.shift()}
function upd(){mine();sandTick();flowTick();aniTick();monTick();fxTick();if(HP<20&&++rg>=240){HP++;rg=0}for(let i=DR.length-1;i>=0;i--){const d=DR[i];d.t++;
  d.vy=Math.min(d.vy+.02,.4);
  const nx=d.x+d.vx;if(!sol(nx,d.y))d.x=nx;else d.vx=0;d.vx*=.95;
  const ny=d.y+d.vy;if(!sol(d.x,ny+.2))d.y=ny;else{if(d.vy>0)d.y=Math.floor(ny+.2)-.2;d.vy=0;d.vx*=.8}
  const q=get(Math.floor(d.x),Math.floor(d.y));
  if(q==11||d.y>H||d.t>18000){DR.splice(i,1);continue}
  if(q==10){d.vy=Math.min(d.vy,.05);d.vx*=.9}
  const dx=d.x-(P.x+P.w/2),dy=d.y-(P.y+P.h/2),dist=Math.hypot(dx,dy);
  if(d.t>20&&dist<1.8){d.x-=dx*.2;d.y-=dy*.2}
  if(d.t>20&&dist<.6){inv[d.id]++;DR.splice(i,1)}}}
const IMS=new Set([53,54,55,56,57,58,59,38]),ironFull=()=>[27,28,29,30].every(k=>IMS.has(S[k])),RCI=[];
{const NA=[53,54,55,56],NB=[57,58,59,38],D=[[3,6,4,3],[4,7,5,4]],NN=['Casco','Peto','Pantalones','Botas'];
 [NA,NB].forEach((A,m)=>A.forEach((id,j)=>{IT[id]={n:NN[j]+(m?' Nano Iron Man':' Iron Man'),c:m?'#d4a017':'#b3141b',s:AS[j]};ARM[id]={s:j,d:D[m][j]}}));
 NA.forEach((id,j)=>RCI.push({o:[id,1],i:[[17,[5,8,7,4][j]],[9,[1,2,1,1][j]]],t:1}));
 NB.forEach((id,j)=>RCI.push({o:[id,1],i:[[NA[j],1],[9,4],[7,4]],t:1}));CRL.push(...NA,...NB,28,29);IT[28]={n:'Repulsor Iron Man',c:'#f2c230',s:'Rp'};IT[29]={n:'Cañón Nano',c:'#5ff',s:'Cn'};
 RCI.push({o:[28,1],i:[[17,6],[9,2]],t:1},{o:[29,1],i:[[28,1],[9,5],[7,4]],t:1})}
const RB=[];
function shoot(h,alt){const nano=h==29,f=P.face,x=P.x+P.w/2+f*.6,y=P.y+.7;swg=8;
 if(!alt){cdn=nano?14:12;const n=nano?3:1;for(let i=0;i<n;i++)RB.push({x,y,vx:f*.7,vy:nano?(i-1)*.05:0,t:0,k:0,n:nano})}
 else if(!nano){cdn=70;RB.push({x,y,vx:f*.9,vy:0,t:0,k:2,n:0,h:[]})}
 else{cdn=60;RB.push({x,y,vx:f*.45,vy:-.01,t:0,k:3,n:1})}}
function rbTick(){for(let i=RB.length-1;i>=0;i--){const b=RB[i];b.x+=b.vx;b.y+=b.vy;b.t++;if(b.k==3)b.vy+=.002;
 let dead=sol(b.x,b.y)||b.t>(b.k==2?24:b.k==3?70:40);const tg=ANI.concat(MON).filter(a=>a.hp>0);
 if(b.k==2){for(const a of tg)if(!b.h.includes(a)&&b.x>a.x-.5&&b.x<a.x+a.w+.5&&b.y>a.y-.6&&b.y<a.y+a.h+.6){b.h.push(a);hitAni(a,14)}}
 else{for(const a of tg)if(b.x>a.x-.2&&b.x<a.x+a.w+.2&&b.y>a.y-.3&&b.y<a.y+a.h+.3){dead=1;if(b.k==0)hitAni(a,6);break}}
 if(dead){if(b.k==3){EX.push({x:b.x,y:b.y,t:18});for(const a of tg)if(a.hp>0&&Math.hypot(a.x+a.w/2-b.x,a.y+a.h/2-b.y)<3.5)hitAni(a,16)}RB.splice(i,1)}}}
function rbDraw(){RB.forEach(b=>{const x=b.x*T-cam.x,y=b.y*T-cam.y;g.save();g.shadowBlur=12;
 if(b.k==2){g.shadowColor='#7ff';g.strokeStyle='rgba(180,255,255,.9)';g.lineWidth=12;g.beginPath();g.moveTo(x,y);g.lineTo(x-b.vx*T*10,y);g.stroke()}
 else if(b.k==3){g.shadowColor='#f80';g.fillStyle='#d4a017';g.fillRect(x-8,y-3,16,6);g.fillStyle='#f33';g.fillRect(x+(b.vx>0?4:-8),y-3,4,6);g.fillStyle='#ffd';g.fillRect(x-(b.vx>0?12:-8),y-2,4,4)}
 else{g.shadowColor=b.n?'#7ff':'#8ff';g.fillStyle=b.n?'#7ff':'#e6ffff';g.beginPath();g.arc(x,y,b.n?4:5,0,7);g.fill()}
 g.restore()})}
function ironExtra(nn,j,r){const[x,y,w,h]=r,t=performance.now()/300;g.save();g.fillStyle='#f2c230';
 if(j==0){g.fillRect(x+2,y+3,w-4,4);g.fillStyle='#fff';g.fillRect(x+4,y+4,2,2);g.fillRect(x+w-6,y+4,2,2)}
 else if(j==1){g.fillRect(x,y+2,w,3);g.fillRect(x,y+h-4,w,3);g.fillStyle=nn?'rgba(120,255,255,'+(.7+.3*Math.sin(t))+')':'#cfefff';g.beginPath();g.arc(x+w/2,y+10,4,0,7);g.fill()}
 else if(j==2)g.fillRect(x,y+h-3,w,3);else g.fillRect(x,y,w,3);
 if(nn){g.strokeStyle='rgba(120,255,255,'+(.5+.4*Math.sin(t))+')';g.lineWidth=2;g.strokeRect(x-1,y-1,w+2,h+2)}
 g.restore()}
const TRP=[],TRL=[];let jdq=0,j404=0,jdc=0;
IT[39]={n:'Poderes de John Doe',c:'#2a2a2a',s:'JD'};CRL.push(39);RCI.push({o:[39,1],i:[[7,8],[9,3]],t:1});
function jd(alt){const x=P.x+P.w/2,f=P.face;swg=10;
 if(!alt){cdn=14;SL.push({t:12,f});for(const a of ANI.concat(MON)){if(a.hp<=0)continue;const dx=a.x+a.w/2-x,dy=a.y+a.h/2-(P.y+P.h/2);if(Math.abs(dy)<2.2&&dx*f>-.5&&Math.abs(dx)<3)hitAni(a,9)}}
 else{cdn=20;if(TRP.length>=3)TRP.shift();TRP.push({x,y:P.y+P.h,t:0});say('Digital Footprint: trampa colocada')}}
function jdTick(){const tg=ANI.concat(MON).filter(a=>a.hp>0);jdc++;if(jdq>0)jdq--;if(j404>0)j404--;
 if(S[sel-1]==39&&jdc%8==0)TRL.push({x:P.x+P.w/2,y:P.y+P.h,t:0});
 for(let i=TRL.length-1;i>=0;i--){const r=TRL[i];if(++r.t>300){TRL.splice(i,1);continue}for(const a of tg)if(Math.abs(a.x+a.w/2-r.x)<.8&&Math.abs(a.y+a.h-r.y)<1.2)a.cor=180}
 for(let i=TRP.length-1;i>=0;i--){const p=TRP[i];if(++p.t>3600){TRP.splice(i,1);continue}for(const a of tg)if(Math.abs(a.x+a.w/2-p.x)<.8&&Math.abs(a.y+a.h-p.y)<1.5){a.slow=600;a._px=a.x;hitAni(a,5);TRP.splice(i,1);break}}
 for(const a of tg){if(a.cor>0){a.cor--;if(a.cor%30==0){a.hp-=1.5;a.hurt=8}}
  if(a.slow>0){a.slow--;if(a._px!=null){const nx=a._px+(a.x-a._px)*.5;if(!hitR(nx,a.y,a.w,a.h))a.x=nx}a._px=a.x}}}
function jdDraw(){TRL.forEach(r=>{g.fillStyle='rgba(150,20,200,'+(.55*(1-r.t/300))+')';g.fillRect(r.x*T-cam.x-10,r.y*T-cam.y-4,20,5)});
 TRP.forEach(p=>{const x=p.x*T-cam.x,y=p.y*T-cam.y;g.fillStyle='#16101f';g.fillRect(x-12,y-6,24,6);g.fillStyle='#b44cff';for(let k=-8;k<=8;k+=8)g.fillRect(x+k-2,y-12,4,6)});spkDraw();
 }
function jdReveal(){if(j404>0||S[sel-1]==39){g.save();g.lineWidth=3;g.font='bold 12px "Courier New"';for(const a of ANI.concat(MON)){if(a.hp<=0||(!(j404>0)&&Math.hypot(a.x+a.w/2-(P.x+P.w/2),a.y+a.h/2-(P.y+P.h/2))>9))continue;const x=a.x*T-cam.x,y=a.y*T-cam.y,w=a.w*T,h=a.h*T;g.strokeStyle='#ff2a3a';g.shadowColor='#f00';g.shadowBlur=10;g.strokeRect(x-2,y-2,w+4,h+4);g.fillStyle='rgba(255,40,60,.25)';g.fillRect(x,y,w,h);
  if(x+w<0||x>VW||y+h<0||y>VH){g.fillStyle='#ff2a3a';g.beginPath();g.arc(Math.min(VW-12,Math.max(12,x+w/2)),Math.min(VH-12,Math.max(12,y+h/2)),6,0,7);g.fill()}}
 g.shadowBlur=0;if(j404>0){g.fillStyle='#ff2a3a';g.fillText('404 ERROR',VW/2-36,100)}g.restore()}}
addEventListener('keydown',e=>{if(e.code=='KeyQ'&&S[sel-1]==39&&!open&&!ske){if(jdq>0)say('404 Error recargando: '+Math.ceil(jdq/60)+'s');else{jdq=1200;j404=240;say('404 Error: ¡todos revelados!')}}});
const SPK=[];let jdr=0,jdrt=0;
function spkKey(){if(SPK.length){if(jdrt>0){say('Retract recargando');return}SPK.forEach(s=>{if(!s.r)s.r=10});jdrt=270;say('Retract: pinchos retraídos');return}
 if(jdr>0){say('Corrupt Energy recargando: '+Math.ceil(jdr/60)+'s');return}
 const f=P.face,bx=Math.floor(P.x+P.w/2),by=Math.floor(P.y+P.h);let n=0;
 for(let k=1;k<=9;k++){const cx=bx+f*k;let gy=-1;for(let y=by-3;y<=by+4;y++){if(sol(cx+.5,y+.5)&&!sol(cx+.5,y-.5)){gy=y;break}}if(gy<0)continue;SPK.push({x:cx+.5,y:gy,t:-k*3,r:0});n++}
 if(!n){say('No hay suelo adelante');return}jdr=1080;swg=12;say('Corrupt Energy: ¡pinchos!')}
function spkTick(){if(jdr>0)jdr--;if(jdrt>0)jdrt--;const tg=ANI.concat(MON).filter(a=>a.hp>0);
 for(let i=SPK.length-1;i>=0;i--){const s=SPK[i];s.t++;if(s.t>840||(s.r&&--s.r<=0)){SPK.splice(i,1);continue}if(s.t<0)continue;
  for(const a of tg){if(Math.abs(a.x+a.w/2-s.x)<.8&&a.y+a.h>s.y-1.8&&a.y<s.y+.3){if(s.t==0){hitAni(a,10);a.vy=-.3}else if(s.t%30==0){a.hp-=2;a.hurt=8}}}}}
function spkDraw(){for(const s of SPK){if(s.t<0)continue;const hh=1.6*Math.min(1,s.t/8)*(s.r?s.r/10:1)*(s.t>780?(840-s.t)/60:1),x=s.x*T-cam.x,y=s.y*T-cam.y;if(hh<=0)continue;g.fillStyle='#1a0f26';g.strokeStyle='#b44cff';g.lineWidth=2;g.beginPath();g.moveTo(x-12,y);g.lineTo(x,y-hh*T);g.lineTo(x+12,y);g.closePath();g.fill();g.stroke()}}
addEventListener('keydown',e=>{if(e.code=='KeyR'&&S[sel-1]==39&&!open&&!ske)spkKey()});
const OPQ=id=>!(id==0||id==4||id==5||id==10||id==11||id==31||id==33||id==34);
function lightDraw(){const cx=Math.floor(cam.x/T),cy=Math.floor(cam.y/T),M=12,x0=cx-M,y0=cy-M,nw=Math.ceil(VW/T)+2*M+2,nh=Math.ceil(VH/T)+2*M+2,LT=new Uint8Array(nw*nh),q=[];
 const inb=(x,y)=>x>=x0&&y>=y0&&x<x0+nw&&y<y0+nh,ix=(x,y)=>(y-y0)*nw+(x-x0);
 const add=(x,y,l)=>{if(!inb(x,y)||l<=0)return;const k=ix(x,y);if(LT[k]>=l)return;LT[k]=l;q.push(x,y)};
 for(let x=x0;x<x0+nw;x++)for(let y=0;y<H&&y<y0+nh;y++){if(OPQ(get(x,y)))break;if(y>=y0)add(x,y,15)}
 for(let x=x0;x<x0+nw;x++)for(let y=Math.max(0,y0);y<y0+nh&&y<H;y++)if(get(x,y)==11)add(x,y,13);
 add(Math.floor(P.x+P.w/2),Math.floor(P.y+P.h/2),12);
 for(let h=0;h<q.length;h+=2){const x=q[h],y=q[h+1],l=LT[ix(x,y)]-1;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(inb(nx,ny)&&!OPQ(get(nx,ny)))add(nx,ny,l)}}
 for(let i=cx;i<=cx+VW/T+1;i++)for(let j=cy;j<=cy+VH/T+1;j++){if(i<0||j<0||i>=W||j>=H)continue;let b;
  if(!OPQ(get(i,j)))b=LT[ix(i,j)];else{b=0;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=i+dx,ny=j+dy;if(inb(nx,ny))b=Math.max(b,LT[ix(nx,ny)])}}
  const a=Math.min(.97,Math.max(0,1-b/11));if(a>.02){g.fillStyle='rgba(0,0,0,'+a+')';g.fillRect(i*T-cam.x,j*T-cam.y,T,T)}}}
const menu=document.getElementById('menu');let started=0,paused=0;
(function(){const c=document.createElement('canvas');c.width=400;c.height=240;const x=c.getContext('2d');
 const gr=x.createLinearGradient(0,0,0,240);gr.addColorStop(0,'#5b9bd5');gr.addColorStop(1,'#bfe0f5');x.fillStyle=gr;x.fillRect(0,0,400,240);
 x.fillStyle='rgba(255,255,255,.92)';for(let i=0;i<6;i++){const cx=(i*77+20)%400,cy=20+(i*37)%70;x.fillRect(cx,cy,40,8);x.fillRect(cx+8,cy-8,24,8)}
 x.fillStyle='#fff3a0';x.fillRect(320,18,22,22);
 const bs=16;let sd=7;const rn=()=>(sd=(sd*16807)%2147483647)/2147483647;
 const blk=(bx,by,c1,c2)=>{x.fillStyle=c1;x.fillRect(bx,by,bs,bs);for(let i=0;i<14;i++){x.fillStyle=c2;x.fillRect(bx+(rn()*bs&~1),by+(rn()*bs&~1),2,2)}};
 const hs=[];for(let i=0;i<25;i++){const h=9+Math.round(2.5*Math.sin(i*.45)+1.5*Math.sin(i*.17+1));hs.push(h);
  for(let j=h;j<15;j++){j==h?blk(i*bs,j*bs,'#6fae48','#4d8a2f'):j<h+4?blk(i*bs,j*bs,'#a9744a','#7e5230'):blk(i*bs,j*bs,'#8a8a8a','#6d6d6d')}}
 for(const t of [4,19]){const h=hs[t];for(let k=1;k<=3;k++)blk(t*bs,(h-k)*bs,'#8a5a2b','#5e3b17');
  for(let dx=-1;dx<=1;dx++)for(let dy=4;dy<=5;dy++)blk((t+dx)*bs,(h-dy)*bs,'#4f9a3a','#34702a');blk(t*bs,(h-6)*bs,'#4f9a3a','#34702a')}
 menu.style.background='linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.45)),url('+c.toDataURL()+') center/cover'})();
const pz=document.getElementById('pause');
function setPause(v){if(!started)return;if(v)saveW();paused=v;pz.classList.toggle('hide',!v);mdown=0;for(const k in keys)keys[k]=0}
addEventListener('keydown',e=>{if(e.code=='Escape'){if(started&&!open&&!ske)setPause(!paused)}else if(!started||paused)e.stopImmediatePropagation()},true);
const LS=(()=>{try{const t=window.localStorage;t.getItem('pm_t');return t}catch(e){const m={};return{getItem:k=>k in m?m[k]:null,setItem:(k,v)=>{m[k]=String(v)},removeItem:k=>{delete m[k]}}}})(),wl=document.getElementById('wl');
const lg=k=>{try{return JSON.parse(LS.getItem(k))}catch(e){return null}},ls=(k,v)=>{try{LS.setItem(k,JSON.stringify(v));return 1}catch(e){return 0}};
const rleEnc=a=>{const o=[];let i=0;while(i<a.length){const v=a[i];let n=1;while(n<255&&i+n<a.length&&a[i+n]===v)n++;o.push(v,n);i+=n}let s='';for(let j=0;j<o.length;j+=8000)s+=String.fromCharCode(...o.slice(j,j+8000));return btoa(s)};
const rleDec=(s,len)=>{const b=atob(s),a=new Uint8Array(len);let k=0;for(let i=0;i<b.length;i+=2){const n=b.charCodeAt(i+1);a.fill(b.charCodeAt(i),k,k+n);k+=n}return a};
let curId=null;const idx=()=>lg('pm_idx')||[];
function saveW(){if(!curId)return;const I=idx(),m=I.find(m=>m.id==curId);if(!m)return;m.t=Date.now();ls('pm_idx',I);
 ls('pm_w_'+curId,{W,OX,px:P.x,py:P.y,inv:cre?invSave:inv,S:cre?Ssave:S,HP,w:rleEnc(w),lv:rleEnc(LV)})}
function resetP(){P.x=W/2;P.y=hgt(W/2|0)-3;P.vx=P.vy=0;P.fs=null;P.fly=0;inv.fill(0);inv[2]=8;inv[6]=4;S.fill(0);HP=20;rg=0;cre=0;invSave=[];Ssave=[];sel=1;open=0;ske=0;
 document.getElementById('crb').textContent='Supervivencia';[MON,ARR,EX,DR,ANI,WV,SL,HK].forEach(l=>l.length=0)}
function enter(){started=1;paused=0;pz.classList.add('hide');wl.classList.add('hide');menu.classList.add('hide');document.getElementById('play').textContent='▶ Continuar';cam.x=P.x*T-VW/2;cam.y=P.y*T-VH/2;mdown=0;for(const k in keys)keys[k]=0}
function newWorld(name){const I=idx();const id='w'+Date.now();I.push({id,name:name||'Mundo '+(I.length+1),t:Date.now()});ls('pm_idx',I);
 W=140;OX=Math.random()*5000|0;w=new Uint8Array(W*H);LV=new Uint8Array(W*H);gen(0,W);resetP();curId=id;saveW();enter()}
function loadWorld(id){const d=lg('pm_w_'+id);if(!d)return 0;try{W=d.W;OX=d.OX;w=rleDec(d.w,W*H);LV=rleDec(d.lv,W*H)}catch(e){return 0}
 resetP();P.x=d.px;P.y=d.py;inv.splice(0,inv.length,...d.inv);S.splice(0,S.length,...d.S);HP=d.HP;curId=id;enter();return 1}
function renderW(){const I=idx().sort((a,b)=>b.t-a.t),L=document.getElementById('wlist');L.innerHTML='';
 if(!I.length){L.innerHTML='<div class="wi">Aún no tienes mundos. ¡Crea uno!</div>';return}
 I.forEach(m=>{const r=document.createElement('div');r.className='wi'+(m.id==curId?' cur':'');
  const s=document.createElement('span');s.textContent=m.name;const sm=document.createElement('small');sm.textContent=new Date(m.t).toLocaleString('es');s.appendChild(sm);
  const p=document.createElement('button');p.textContent='▶ Jugar';p.onclick=()=>{if(m.id==curId)enter();else{saveW();if(!loadWorld(m.id))renderW()}};
  const d=document.createElement('button');d.textContent='🗑';d.title='Borrar';d.onclick=()=>{if(!d.dataset.c){d.dataset.c=1;d.textContent='¿Seguro?';return}
   try{LS.removeItem('pm_w_'+m.id)}catch(e){}ls('pm_idx',idx().filter(x=>x.id!=m.id));if(m.id==curId){curId=null;started=0;document.getElementById('play').textContent='▶ Jugar'}renderW()};
  r.append(s,p,d);L.appendChild(r)})}
setInterval(()=>{if(started&&!paused)saveW()},10000);addEventListener('pagehide',()=>{if(started)saveW()});
const SP=['¡Hecho de papel!','¡Ahora en 2D!','¡Cuadrado y divertido!','¡Pica, pica, pica!','¡Cuidado con la lava!','¡100% reciclable!','¡Construye algo grande!'];
document.getElementById('sp').textContent=SP[Math.random()*SP.length|0];
document.getElementById('play').onclick=()=>{try{if(curId)enter();else{const I=idx().sort((a,b)=>b.t-a.t);if(!(I[0]&&loadWorld(I[0].id)))newWorld()}}catch(e){try{newWorld()}catch(e2){document.getElementById('sp').textContent='Error: '+(e2&&e2.message)}}};
document.getElementById('wb').onclick=()=>{wl.style.background=menu.style.background;renderW();wl.classList.remove('hide')};
document.getElementById('wback').onclick=()=>wl.classList.add('hide');
document.getElementById('wnew').onclick=()=>{const n=document.getElementById('wn');saveW();newWorld(n.value.trim());n.value=''};
document.getElementById('mnb').onclick=()=>setPause(!paused);
document.getElementById('resume').onclick=()=>setPause(0);
document.getElementById('home').onclick=()=>{saveW();setPause(0);started=0;open=0;ske=0;document.getElementById('play').textContent='▶ Continuar';menu.classList.remove('hide')};
document.getElementById('info').onclick=()=>{const d=document.getElementById('md');d.style.display=d.style.display=='none'?'':'none'};

/* ===== Poderes de Sonic: Shift = supervelocidad · C = bolita (C parado + soltar = Spin Dash) ===== */
const TR=[],PT=[];
try{P.sonic=localStorage.getItem('pmsonic')=='1'}catch(e){P.sonic=false}
P.sp=1;P.ch=0;P.dash=0;P.jb=0;P.ball=false;P.ang=0;
function sonicBtn(){const b=document.getElementById('snb');if(b)b.textContent='🦔 Sonic: '+(P.sonic?'ON':'OFF')}
(function(){const b=document.getElementById('snb');if(!b)return;sonicBtn();
 b.onclick=()=>{P.sonic=!P.sonic;try{localStorage.setItem('pmsonic',P.sonic?'1':'0')}catch(e){}sonicBtn();b.blur();
  say(P.sonic?'Sonic ON · Shift: supervelocidad · C: bolita':'Sonic OFF')}})();
function sonicVx(L,R){const b=(R?1:0)*.14-(L?1:0)*.14;
 if(!P.sonic){P.ball=false;P.sp=1;P.dash=0;P.ch=0;P.jb=0;return b}
 const sh=keys.ShiftLeft||keys.ShiftRight,cb=keys.KeyC,mv=L||R;
 if(cb&&P.gnd&&!mv&&!P.dash)P.ch=Math.min(40,P.ch+1);
 else if(P.ch>0){if(!cb&&P.ch>=14){P.dash=12+(P.ch*.7|0);say('¡Spin Dash!')}P.ch=0}
 if(P.dash>0){P.dash--;P.sp=3.2;return P.face*.5}
 let t=1;if(mv){if(sh)t=3.2;else if(cb)t=1.7}
 P.sp+=(t-P.sp)*(t>P.sp?.05:.2);if(Math.abs(P.sp-1)<.02)P.sp=1;
 return b*P.sp}
function sonicTick(){
 for(let i=TR.length-1;i>=0;i--)if(--TR[i].t<=0)TR.splice(i,1);
 for(let i=PT.length-1;i>=0;i--){const q=PT[i];q.x+=q.vx;q.y+=q.vy;q.vy+=.01;if(--q.t<=0)PT.splice(i,1)}
 if(!P.sonic)return;
 if(P.gnd)P.jb=0;else if(P.vy<-.05&&!P.fly)P.jb=1;
 P.ball=!!(keys.KeyC||P.dash>0||P.jb)&&!P.fly;
 P.ang+=(P.ball?(P.dash>0?.7:P.ch>0?.5:.3+Math.abs(P.vx)*1.6):0)*P.face;
 if(P.sp>1.8||P.dash>0)TR.push({x:P.x,y:P.y,b:P.ball,f:P.face,a:P.ang,t:9});
 if(P.ch>0&&P.gnd&&P.ch%3==0)PT.push({x:P.x+P.w/2-P.face*.3,y:P.y+P.h-.1,vx:-P.face*(.04+Math.random()*.05),vy:-.08-Math.random()*.06,t:14,c:'#e6d49a'});
 const bx=P.x+P.w/2,by=P.y+P.h-.6,dm=(P.dash>0||P.sp>2.2)?8:4;
 for(const a of ANI.concat(MON)){
  if(a.sh>0)a.sh--;
  if(!P.ball||a.sh>0)continue;
  if(bx>a.x-.55&&bx<a.x+a.w+.55&&by>a.y-.55&&by<a.y+a.h+.55){
   hitAni(a,dm);a.sh=12;
   for(let k=0;k<6;k++)PT.push({x:bx,y:by,vx:(Math.random()-.5)*.25,vy:-Math.random()*.15,t:16,c:k%2?'#ffffff':'#4aa3ff'});
   if(P.vy>0&&by<a.y+a.h*.4){P.vy=-.28;P.fs=null}
   else if(P.dash>0){P.dash=Math.max(0,P.dash-6)}}}}
function sonicBallShape(r,spin){
 g.fillStyle='#1b4fd8';g.strokeStyle='#0a1f66';g.lineWidth=2;g.beginPath();
 for(let i=0;i<16;i++){const a=i*Math.PI/8,rr=i%2?r*.85:r*1.3;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}
 g.closePath();g.fill();g.stroke();
 g.fillStyle='#2a6bff';g.beginPath();g.arc(0,0,r*.85,0,7);g.fill();g.stroke();
 g.strokeStyle='#bcd6ff';g.lineWidth=3;g.beginPath();g.arc(0,0,r*.5,.2,Math.PI*1.3);g.stroke();
 g.fillStyle='#f4c79b';g.beginPath();g.arc(r*.3,r*.2,r*.26,0,7);g.fill()}
function sonicBall(px,py){
 if(!P.sonic||!P.ball)return false;
 const r=.5*T,cx=px+P.w*T/2,cy=py+P.h*T-.6*T+(P.ch>0?Math.sin(P.ch*2)*1.5:0);
 g.save();
 if(P.ch>0||P.dash>0){g.shadowColor='#4aa3ff';g.shadowBlur=8+(P.ch>0?P.ch*.4:12)}
 g.translate(cx,cy);g.rotate(P.ang);sonicBallShape(r);g.restore();return true}
function sonicTrail(){
 if(!P.sonic)return;
 for(const t of TR){const x=t.x*T-cam.x,y=t.y*T-cam.y;g.save();g.globalAlpha=t.t/9*.35;
  if(t.b){g.translate(x+P.w*T/2,y+P.h*T-.6*T);g.rotate(t.a);sonicBallShape(.5*T)}else skinDraw(x,y);g.restore()}
 if(P.sp>1.8&&!P.dash){const px=P.x*T-cam.x,py=P.y*T-cam.y;g.save();g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=2;
  for(let i=0;i<5;i++){const yy=py+6+i*10,l=18+((i*37+(tm|0)*5)%22);g.beginPath();g.moveTo(px+(P.face>0?-4:P.w*T+4),yy);g.lineTo(px+(P.face>0?-4-l:P.w*T+4+l),yy);g.stroke()}g.restore()}}
function sonicFX(){
 if(!P.sonic)return;
 for(const q of PT){g.globalAlpha=Math.min(1,q.t/10);g.fillStyle=q.c;g.fillRect(q.x*T-cam.x-2,q.y*T-cam.y-2,4,4)}g.globalAlpha=1;
 if(P.ch>0){const px=P.x*T-cam.x,py=P.y*T-cam.y-12;g.fillStyle='rgba(0,0,0,.45)';g.fillRect(px-8,py,38,6);g.fillStyle=P.ch>=14?'#4aa3ff':'#aaa';g.fillRect(px-7,py+1,36*P.ch/40,4)}}
(function loop(){if(started&&(!paused||NETON))step();draw();requestAnimationFrame(loop)})();
