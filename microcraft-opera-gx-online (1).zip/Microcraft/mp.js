/* ===== Microcraft · Multijugador online (PC <-> celular) · v5 =====
   - Conexión directa entre jugadores con WebRTC (canal de datos).
   - Para "encontrarse" se usan VARIOS servidores públicos a la vez (PeerJS + brokers MQTT de HiveMQ y EMQX):
     solo intercambian el saludo inicial; después el juego va directo entre los dos dispositivos.
     Si uno está caído, los otros lo cubren. La sala se vuelve a registrar sola si se pierde la conexión.
   - Para redes que bloquean la conexión directa se incluyen servidores TURN públicos; en "Avanzado" puedes poner el tuyo.
   - El ANFITRIÓN simula mobs, animales, agua/lava y arena. Los invitados reciben todo eso.
   - Se comparten: bloques, puertas, explosiones, jugadores (skin/objeto en mano/armadura),
     mobs, animales, flechas, hora del día y la expansión del mundo.
   Se pueden cambiar los servidores definiendo window.MC_SIGNAL, window.MC_MQTT o window.MC_ICE antes de cargar este archivo. */
(function(){
const SIG=Object.assign({host:'0.peerjs.com',port:443,path:'/',key:'peerjs',secure:true},window.MC_SIGNAL||{});
const MQTT_URLS=window.MC_MQTT||['wss://broker.hivemq.com:8884/mqtt','wss://broker.emqx.io:8084/mqtt'];
const TOPIC='microcraft-mp-v1/';
const ICE_DEF=[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'},{urls:'stun:global.stun.twilio.com:3478'},
 {urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turn:openrelay.metered.ca:443?transport=tcp'],username:'openrelayproject',credential:'openrelayproject'}];
/* TURN propio (opcional): "turn:servidor:3478,usuario,clave" (varios separados por ;) */
function customTurn(){const l=[];try{const t=localStorage.getItem('pm_turn');if(t)t.split(';').forEach(s=>{const a=s.split(',').map(x=>x.trim());if(/^turns?:/i.test(a[0])&&a[1]&&a[2])l.push({urls:a[0],username:a[1],credential:a[2]})})}catch(e){}return l}
const iceList=()=>(window.MC_ICE||ICE_DEF).slice().concat(customTurn());
const PFX='microcraft-',MAXG=3,CH=12000;
const r2=v=>Math.round(v*100)/100;
const $=id=>document.getElementById(id);
const N=window.MC_NET={role:null,code:'',myId:0,name:'Jugador',peers:new Map(),players:new Map(),batch:[],
 ex:undefined,applying:false,noEmit:0,dropFor:null,nid:0,eA:new Map(),eM:new Map(),snap:null,lastExt:0,tick:0,lastSkin:'',sig:null,tmo:0,
 hosting:false,joining:false,cancel:null,early:new Map(),rt:0,wl:null};

/* ---------- Señalización: varios servidores a la vez ---------- */
const rid=n=>{const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let o='';for(let i=0;i<n;i++)o+=a[Math.random()*a.length|0];return o};
const mqName=u=>{try{return new URL(u.replace(/^ws/,'http')).hostname.replace(/^(broker|test)\./,'').split('.')[0]}catch(e){return 'MQTT'}};

/* Transporte 1: servidor PeerJS (WebSocket) */
function tPeer(id,ev){
 const tok=Math.random().toString(36).slice(2),
  url=(SIG.secure?'wss':'ws')+'://'+SIG.host+(SIG.port?':'+SIG.port:'')+SIG.path+'peerjs?key='+SIG.key+'&id='+id+'&token='+tok;
 let ws;const s={name:'PeerJS',open:false,hb:0,
  send(type,dst,payload){if(ws&&ws.readyState==1)ws.send(JSON.stringify({type,dst,payload}))},
  close(){clearInterval(s.hb);s.open=false;try{ws.close()}catch(e){}}};
 try{ws=new WebSocket(url)}catch(e){setTimeout(()=>ev.close(false),0);return s}
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(x){return}
  if(m.type=='OPEN'){s.open=true;s.hb=setInterval(()=>{if(ws.readyState==1)ws.send('{"type":"HEARTBEAT"}')},5000);ev.open()}
  else ev.msg(m)};
 ws.onclose=()=>{clearInterval(s.hb);const was=s.open;s.open=false;ev.close(was)};
 ws.onerror=()=>{};
 return s}

/* Transporte 2: broker MQTT público por WebSocket (cliente MQTT 3.1.1 mínimo, QoS 0) */
function tMqtt(url,id,ev){
 const enc=new TextEncoder(),dec=new TextDecoder();let ws,buf=new Uint8Array(0);
 const cat=(...a)=>{let n=0;for(const x of a)n+=x.length;const o=new Uint8Array(n);let k=0;for(const x of a){o.set(x,k);k+=x.length}return o};
 const str=x=>{const b=enc.encode(x);return cat(Uint8Array.of(b.length>>8,b.length&255),b)};
 const pkt=(h,body)=>{const rl=[];let n=body.length;do{let d=n%128;n=Math.floor(n/128);if(n>0)d|=128;rl.push(d)}while(n>0);return cat(Uint8Array.of(h,...rl),body)};
 const s={name:mqName(url),open:false,hb:0,
  send(type,dst,payload){if(s.open&&ws.readyState==1)ws.send(pkt(0x30,cat(str(TOPIC+dst),enc.encode(JSON.stringify({type,src:id,payload})))))},
  close(){clearInterval(s.hb);s.open=false;try{ws.close()}catch(e){}}};
 try{ws=new WebSocket(url,'mqtt')}catch(e){setTimeout(()=>ev.close(false),0);return s}
 ws.binaryType='arraybuffer';
 ws.onopen=()=>ws.send(pkt(0x10,cat(str('MQTT'),Uint8Array.of(4,2,0,60),str('mc-'+rid(10)))));
 const handle=(h,b)=>{const t=h>>4;
  if(t==2){if(b[1]==0)ws.send(pkt(0x82,cat(Uint8Array.of(0,1),str(TOPIC+id),Uint8Array.of(0))));else{try{ws.close()}catch(e){}}}
  else if(t==9){if(b.length>2&&b[2]<128){s.open=true;s.hb=setInterval(()=>{if(ws.readyState==1)ws.send(Uint8Array.of(0xC0,0))},25000);ev.open()}else{try{ws.close()}catch(e){}}}
  else if(t==3){const qos=(h>>1)&3,tl=(b[0]<<8)|b[1];let o=2+tl;if(qos)o+=2;let m;try{m=JSON.parse(dec.decode(b.slice(o)))}catch(e){return}if(m&&m.type)ev.msg(m)}};
 ws.onmessage=e=>{if(typeof e.data=='string')return;buf=cat(buf,new Uint8Array(e.data));
  for(;;){if(buf.length<2)return;let rl=0,mul=1,i=1,x;
   do{if(i>=buf.length)return;x=buf[i++];rl+=(x&127)*mul;mul*=128}while((x&128)&&i<5);
   if(buf.length<i+rl)return;const h=buf[0],body=buf.slice(i,i+rl);buf=buf.slice(i+rl);handle(h,body)}};
 ws.onclose=()=>{clearInterval(s.hb);const was=s.open;s.open=false;ev.close(was)};
 ws.onerror=()=>{};
 return s}

/* Reúne todos los transportes: envía por todos los que estén abiertos, se reconecta solo, descarta mensajes duplicados
   y vuelve a enviar lo pendiente a un servidor que se conecta tarde. */
function Sigs(id,onmsg,onchg){
 const S={id,list:[],closed:false,seen:new Set(),log:[],
  send(type,dst,payload,keep){payload=Object.assign({mid:rid(8)},payload);
   if(keep!==false){S.log.push({type,dst,payload});if(S.log.length>300)S.log.shift()}
   for(const t of S.list)if(t.s&&t.s.open)t.s.send(type,dst,payload)},
  anyOpen:()=>S.list.some(t=>t.s&&t.s.open),
  states:()=>S.list.map(t=>({n:t.name,ok:!!(t.s&&t.s.open)})),
  close(){S.closed=true;for(const t of S.list){clearTimeout(t.timer);if(t.s)t.s.close()}}};
 const conn=t=>{if(S.closed)return;let s;
  const ev={open(){t.tries=0;for(const m of S.log)s.send(m.type,m.dst,m.payload);onchg&&onchg()},
   msg(m){const mid=m.payload&&m.payload.mid;if(mid){if(S.seen.has(mid))return;S.seen.add(mid);if(S.seen.size>600)S.seen.clear()}onmsg(m,t.name)},
   close(){if(t.s===s)t.s=null;onchg&&onchg();if(!S.closed)t.timer=setTimeout(()=>conn(t),Math.min(15000,1200*Math.pow(2,Math.min(t.tries++,4))))}};
  s=t.make(ev);t.s=s};
 S.list.push({name:'PeerJS',tries:0,timer:0,s:null,make:ev=>tPeer(id,ev)});
 for(const u of MQTT_URLS)S.list.push({name:mqName(u),tries:0,timer:0,s:null,make:ev=>tMqtt(u,id,ev)});
 S.list.forEach(conn);
 return S}

/* ---------- Envío ---------- */
function sendTo(p,o,unrel){const ch=unrel&&p.u&&p.u.readyState=='open'&&p.u.bufferedAmount<2e5?p.u:p.r;
 if(ch&&ch.readyState=='open'){try{ch.send(JSON.stringify(o))}catch(e){}}}
const toHost=o=>{const p=N.peers.get('host');if(p)sendTo(p,o)};
function bcast(o,unrel,exceptId){for(const p of N.peers.values())if(p.ok&&p.id!==exceptId)sendTo(p,o,unrel)}

/* ---------- Jugadores remotos ---------- */
function skinCv(arr){const c=document.createElement('canvas');c.width=8;c.height=17;const x=c.getContext('2d');
 if(Array.isArray(arr))arr.forEach((col,i)=>{if(col&&typeof col=='string'&&/^#[0-9a-f]{3,8}$/i.test(col)){x.fillStyle=col;x.fillRect(i%8,(i/8)|0,1,1)}});return c}
function addPlayer(id,name,skin,peer){let p=N.players.get(id);
 if(!p){p={id,name:String(name||'Jugador').slice(0,16),ax:0,y:0,sx:0,sy:0,f:1,h:0,sw:0,b:0,a:0,a4:[0,0,0,0],hp:20,peer,seen:false,last:performance.now()};N.players.set(id,p)}
 p.name=String(name||p.name).slice(0,16);if(skin){p.skin=skin;p.cv=skinCv(skin)}if(!p.cv)p.cv=skinCv(null);if(peer)p.peer=peer;return p}
function applyState(p,o){p.ax=o.x;p.y=o.y;p.f=o.f;p.h=o.h;p.sw=o.sw;p.b=o.b;p.a=o.a;p.a4=o.a4||p.a4;p.hp=o.hp;p.last=performance.now();
 if(!p.seen||Math.abs(p.sx-p.ax)>20){p.sx=p.ax;p.sy=p.y;p.seen=true}}
function myState(){return{t:'p',x:r2(P.x+OX),y:r2(P.y),f:P.face,h:S[sel-1]||0,sw:swg>0?1:0,b:P.ball?1:0,a:r2(P.ang||0),a4:[S[27]||0,S[28]||0,S[29]||0,S[30]||0],hp:HP}}
const others=()=>[...N.players.values()];

function drawRemote(p){
 p.sx+=(p.ax-p.sx)*.4;p.sy+=(p.y-p.sy)*.4;
 const px=(p.sx-OX)*T-cam.x,py=p.sy*T-cam.y,w=P.w*T,h=P.h*T;
 if(px<-90||px>VW+90||py<-120||py>VH+120)return;
 g.fillStyle='rgba(0,0,0,.2)';g.fillRect(px+3,py+3,w,h);
 if(p.b&&typeof sonicBallShape=='function'){g.save();g.translate(px+w/2,py+h-.6*T);g.rotate(p.a);sonicBallShape(.5*T);g.restore()}
 else{
  g.save();g.imageSmoothingEnabled=false;
  if(p.f<0){g.translate(px+w,py);g.scale(-1,1);g.drawImage(p.cv,0,0,8,17,0,0,w,h)}else g.drawImage(p.cv,0,0,8,17,px,py,w,h);
  g.restore();g.strokeStyle='#3b2f20';g.lineWidth=2;g.strokeRect(px,py,w,h);
  /* armadura y objeto en mano: se reutilizan las funciones del juego cambiando temporalmente el estado */
  const sv={f:P.face,s:S[sel-1],sw:swg,md:mdown,op:open,a:[S[27],S[28],S[29],S[30]]};
  try{P.face=p.f;S[sel-1]=p.h;swg=p.sw?12:0;mdown=0;open=0;for(let j=0;j<4;j++)S[27+j]=p.a4[j]||0;
   armorDraw(px,py);held(px,py)}catch(e){}
  P.face=sv.f;S[sel-1]=sv.s;swg=sv.sw;mdown=sv.md;open=sv.op;for(let j=0;j<4;j++)S[27+j]=sv.a[j];
 }
 /* nombre y vida */
 g.save();g.font='bold 12px Georgia';g.textAlign='center';g.lineWidth=3;g.strokeStyle='rgba(0,0,0,.75)';g.fillStyle='#fff';
 g.strokeText(p.name,px+w/2,py-12);g.fillText(p.name,px+w/2,py-12);
 g.fillStyle='rgba(0,0,0,.55)';g.fillRect(px+w/2-14,py-8,28,4);g.fillStyle='#e03030';g.fillRect(px+w/2-14,py-8,28*Math.max(0,Math.min(20,p.hp))/20,4);
 g.restore()}

/* ---------- Bloques ---------- */
const _set=set;
set=function(x,y,v){_set(x,y,v);if(N.role&&!N.noEmit&&!N.applying&&x>=0&&y>=0&&x<W&&y<H)N.batch.push([x+OX,y,v,N.ex])};
const _gen=gen;
gen=function(a,b){N.noEmit++;try{_gen(a,b)}finally{N.noEmit--}};
function applyEdits(list,from){
 const wa=N.applying,we=N.ex;N.applying=N.role=='client';N.ex=from;
 try{for(const e of list){const x=e[0]-OX;if(x>=0&&x<W&&e[1]>=0&&e[1]<H)set(x,e[1],e[2])}}finally{N.applying=wa;N.ex=we}}
function flush(){
 if(!N.batch.length)return;const b=N.batch;N.batch=[];
 if(N.role=='client'){for(let i=0;i<b.length;i+=600)toHost({t:'b',e:b.slice(i,i+600).map(e=>[e[0],e[1],e[2]])});return}
 for(const p of N.peers.values()){if(!p.ok)continue;const l=b.filter(e=>e[3]!==p.id).map(e=>[e[0],e[1],e[2]]);
  for(let i=0;i<l.length;i+=600)sendTo(p,{t:'b',e:l.slice(i,i+600)})}}

/* ---------- Expansión del mundo ---------- */
const _extend=extend;
extend=function(dir){
 if(N.role=='client'){const n=performance.now();if(n-N.lastExt>700){N.lastExt=n;toHost({t:'ext',d:dir,x:r2(P.x+OX)})}return}
 const oW=W;_extend(dir);
 if(N.role=='host'&&W!=oW){
  /* se envía el chunk nuevo + 4 columnas del borde viejo (las cuevas/minerales generados "se salen" del chunk) */
  const C=W-oW,M=Math.min(4,oW),B=C+M,c0=dir<0?0:oW-M,cw=new Uint8Array(B*H),cl=new Uint8Array(B*H);
  for(let y=0;y<H;y++){cw.set(w.subarray(y*W+c0,y*W+c0+B),y*B);cl.set(LV.subarray(y*W+c0,y*W+c0+B),y*B)}
  flush();bcast({t:'chunk',d:dir,a0:OX+c0,n:C,m:M,w:rleEnc(cw),lv:rleEnc(cl)})}};
function applyChunk(o){
 const C=o.n,M=o.m,B=C+M,dir=o.d;
 if(dir<0?(o.a0+C!==OX):(o.a0+M!==OX+W))return;
 const cw=rleDec(o.w,B*H),cl=rleDec(o.lv,B*H),oW=W,nW=W+C,nw=new Uint8Array(nW*H),nl=new Uint8Array(nW*H),off=dir<0?C:0;
 for(let y=0;y<H;y++){nw.set(w.subarray(y*oW,y*oW+oW),y*nW+off);nl.set(LV.subarray(y*oW,y*oW+oW),y*nW+off)}
 /* columnas nuevas + margen (el margen sobrescribe lo que el anfitrión cambió al generar) */
 const dst0=dir<0?0:oW-M;
 for(let y=0;y<H;y++){nw.set(cw.subarray(y*B,y*B+B),y*nW+dst0);nl.set(cl.subarray(y*B,y*B+B),y*nW+dst0)}
 w=nw;LV=nl;W=nW;
 if(dir<0){OX-=C;P.x+=C;cam.x+=C*T;mtx+=C;mp=0;[ANI,MON,DR,HK,WV,ARR,EX].forEach(l=>l.forEach(e=>e.x+=C))}}

/* ---------- Mobs / animales ---------- */
netTgt=function(m){
 if(N.role!='host'||!N.players.size)return P;
 let best=P,bd=Math.hypot(P.x-m.x,P.y-m.y);
 for(const p of N.players.values()){if(!p.seen)continue;const x=p.ax-OX,d=Math.hypot(x-m.x,p.y-m.y);if(d<bd){bd=d;best={x,y:p.y,rp:p}}}
 return best};
netHurt=function(tp,n){if(tp&&tp.rp&&tp.rp.peer)sendTo(tp.rp.peer,{t:'hurt',n})};
netArrowHit=function(a){if(N.role!='host')return null;
 for(const p of N.players.values()){if(!p.seen)continue;const x=p.ax-OX;if(a.x>x&&a.x<x+P.w&&a.y>p.y&&a.y<p.y+P.h)return{x,y:p.y,rp:p}}return null};
netBoom=function(cx,cy){if(N.role!='host')return;
 for(const p of N.players.values()){if(!p.seen||!p.peer)continue;const d=Math.hypot(p.ax-OX+P.w/2-cx,p.y+P.h/2-cy);
  if(d<5)sendTo(p.peer,{t:'hurt',n:Math.max(1,Math.round(10*(1-d/5)))})}};
netFar=function(x){if(N.role=='host')for(const p of N.players.values())if(p.seen&&Math.abs(p.ax-OX-x)<=90)return false;return Math.abs(x-P.x)>90};

/* el anfitrión simula también las zonas donde están los invitados lejos de él */
function remoteSim(fn,get,setc){const c=get();
 for(const p of N.players.values()){if(!p.seen)continue;const lx=p.ax-OX;if(Math.abs(lx-P.x)<140)continue;
  const px=P.x;setc(c-1);P.x=lx;try{fn()}finally{P.x=px}}
 setc(c)}
const _flow=flowTick,_sand=sandTick,_ani=aniTick,_mon=monTick,_spawn=monSpawn,_hit=hitAni,_drop=drop,_dfx=drawFX;
flowTick=function(){if(N.role=='client')return;_flow();if(N.role=='host')remoteSim(_flow,()=>fk,v=>{fk=v})};
sandTick=function(){if(N.role=='client')return;_sand();if(N.role=='host')remoteSim(_sand,()=>sk,v=>{sk=v})};
monSpawn=function(){_spawn();if(N.role!='host')return;
 for(const p of N.players.values()){if(!p.seen)continue;const px=P.x;P.x=p.ax-OX;try{_spawn()}finally{P.x=px}}};
function smoothEnts(){for(const e of ANI.concat(MON)){if(e.ax==null)continue;const tx=e.ax-OX;
 if(Math.abs(tx-e.x)>6||Math.abs(e.ty-e.y)>6){e.x=tx;e.y=e.ty}else{e.x+=(tx-e.x)*.35;e.y+=(e.ty-e.y)*.35}}}
aniTick=function(){if(N.role=='client'){smoothEnts();return}_ani()};
monTick=function(){if(N.role=='client'){dayT++;for(const a of ARR){a.x+=a.vx;a.y+=a.vy;a.vy+=.004}return}_mon()};
hitAni=function(a,dm){
 if(N.role!='client')return _hit(a,dm);
 if(!a||a.nid==null)return;
 const d=dm||wdmg(S[sel-1]);swg=12;a.hurt=20;
 toHost({t:'hit',k:a.mon?'m':'a',id:a.nid,d,fx:r2(P.x+OX)})};
drop=function(tx,ty,id){
 if(N.dropFor){sendTo(N.dropFor,{t:'drop',x:tx+OX,y:ty,id});return}
 _drop(tx,ty,id)};
drawFX=function(){_dfx();if(N.role)for(const p of N.players.values())if(p.seen)drawRemote(p)};

function entsMsg(){
 const nid=e=>e.nid||(e.nid=++N.nid),A=[],M=[],R=[],X=[];
 for(const a of ANI)A.push([nid(a),r2(a.x+OX),r2(a.y),a.t,a.face,a.hurt|0,Math.round(a.hp),a.w,a.h]);
 for(const m of MON)M.push([nid(m),r2(m.x+OX),r2(m.y),m.t,m.face,m.hurt|0,Math.round(m.hp),m.w,m.h,m.fuse|0]);
 for(const a of ARR)R.push([r2(a.x+OX),r2(a.y),a.vx,a.vy]);
 for(const e of EX)X.push([r2(e.x+OX),r2(e.y),e.t]);
 return{t:'ents',a:A,m:M,r:R,x:X}}
function syncList(list,map,rows,mon){
 const seen=new Set();
 for(const r of rows){let e=map.get(r[0]);
  if(!e){e={nid:r[0],mon:mon?1:0,x:r[1]-OX,y:r[2],w:r[7],h:r[8],vx:0,vy:0,fuse:0,gnd:false,cd:0,kb:0,flee:0,dir:0,tmr:0,sh:0};map.set(r[0],e);list.push(e)}
  e.ax=r[1];e.ty=r[2];e.t=r[3];e.face=r[4];e.hurt=r[5];e.hp=r[6];if(mon)e.fuse=r[9];seen.add(r[0])}
 for(let i=list.length-1;i>=0;i--){const e=list[i];if(!seen.has(e.nid)){list.splice(i,1);map.delete(e.nid)}}}
function applyEnts(o){
 syncList(ANI,N.eA,o.a,false);syncList(MON,N.eM,o.m,true);
 ARR.length=0;for(const r of o.r)ARR.push({x:r[0]-OX,y:r[1],vx:r[2],vy:r[3],t:0});
 EX.length=0;for(const r of o.x)EX.push({x:r[0]-OX,y:r[1],t:r[2]})}

/* ---------- Mensajes ---------- */
function snapshotTo(p){
 flush();
 const s=JSON.stringify({W,OX,w:rleEnc(w),lv:rleEnc(LV)}),n=Math.ceil(s.length/CH);
 for(let i=0;i<n;i++){const o={t:'snap',i,n,d:s.slice(i*CH,(i+1)*CH)};
  if(i==n-1)o.ex={ax:r2(P.x+OX),y:r2(P.y),dayT};sendTo(p,o)}
 p.ok=true}
function finishSnap(ex){
 const o=JSON.parse(N.snap.join(''));N.snap=null;
 W=o.W;OX=o.OX;w=rleDec(o.w,W*H);LV=rleDec(o.lv,W*H);
 resetP();curId=null;N.eA.clear();N.eM.clear();
 P.x=ex.ax-OX;P.y=ex.y;dayT=ex.dayT;NETON=true;N.role='client';
 enter();hidePanel();hud();wake();say('¡Conectado! Mundo del anfitrión')}

function onHost(p,raw){
 let m;try{m=JSON.parse(raw)}catch(e){return}p.last=performance.now();
 switch(m.t){
 case 'hello':{if(p.id)return;let id=1;const used=new Set([...N.peers.values()].map(q=>q.id));while(used.has(id))id++;p.id=id;
  const pl=addPlayer(id,m.name,m.skin,p);
  const list=[{id:0,name:N.name,skin:skn.slice()}].concat(others().filter(q=>q.id!==id).map(q=>({id:q.id,name:q.name,skin:q.skin})));
  sendTo(p,{t:'welcome',id,list});snapshotTo(p);
  bcast({t:'join',id,name:pl.name,skin:pl.skin},false,id);say(pl.name+' se unió');hud();break}
 case 'p':{const pl=N.players.get(p.id);if(!pl)return;applyState(pl,m);bcast(Object.assign({},m,{id:p.id}),true,p.id);break}
 case 'skin':{const pl=N.players.get(p.id);if(!pl)return;addPlayer(p.id,pl.name,m.d);bcast({t:'skin',id:p.id,d:m.d},false,p.id);break}
 case 'b':if(p.ok&&Array.isArray(m.e))applyEdits(m.e,p.id);break;
 case 'ext':{const lx=m.x-OX;if(m.d<0&&lx<16||m.d>0&&lx>W-16)extend(m.d);break}
 case 'hit':{const list=m.k=='m'?MON:ANI,e=list.find(q=>q.nid===m.id);if(!e||!(e.hp>0))return;
  const sx=P.x,sw=swg;P.x=m.fx-OX;N.dropFor=p;try{_hit(e,Math.min(40,+m.d||1))}finally{N.dropFor=null;P.x=sx;swg=sw}break}
 case 'bye':dropPeer(p);break}}
function onClient(raw){
 let m;try{m=JSON.parse(raw)}catch(e){return}const p=N.peers.get('host');if(p)p.last=performance.now();
 switch(m.t){
 case 'welcome':N.myId=m.id;m.list.forEach(q=>addPlayer(q.id,q.name,q.skin));N.snap=[];break;
 case 'snap':if(!N.snap)N.snap=[];N.snap[m.i]=m.d;if(m.i==m.n-1)finishSnap(m.ex);break;
 case 'b':if(NETON)applyEdits(m.e,undefined);break;
 case 'chunk':if(NETON)applyChunk(m);break;
 case 'p':{const pl=N.players.get(m.id);if(pl)applyState(pl,m);break}
 case 'ents':if(NETON)applyEnts(m);break;
 case 'time':dayT=m.d;break;
 case 'hurt':hurt(m.n);break;
 case 'drop':_drop(Math.floor(m.x-OX),Math.floor(m.y),m.id);break;
 case 'join':addPlayer(m.id,m.name,m.skin);say(m.name+' se unió');hud();break;
 case 'skin':{const pl=N.players.get(m.id);if(pl)addPlayer(m.id,pl.name,m.d);break}
 case 'leave':{const pl=N.players.get(m.id);if(pl){say(pl.name+' salió');N.players.delete(m.id);hud()}break}
 case 'bye':leave('El anfitrión cerró la sala');break}}

function dropPeer(p){
 if(!p||p.dead)return;p.dead=true;try{p.pc.close()}catch(e){}
 for(const [k,v] of N.peers)if(v===p)N.peers.delete(k);
 if(N.role=='host'&&p.id){const pl=N.players.get(p.id);N.players.delete(p.id);if(pl)say(pl.name+' salió');bcast({t:'leave',id:p.id});hud()}
 else if(N.role=='client'&&N.peers.size==0&&!p.silent)leave('Se perdió la conexión con el anfitrión')}

/* ---------- WebRTC ---------- */
function mkPeer(key,handlerMsg){
 let pc;try{pc=new RTCPeerConnection({iceServers:iceList()})}catch(e){pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]})}
 const p={key,pc,r:null,u:null,ok:false,id:0,pend:[],rd:false,last:performance.now(),born:performance.now(),dead:false,cid:''};
 const wire=ch=>{ch.onmessage=e=>handlerMsg(p,e.data);ch.onclose=()=>{if(ch===p.r)dropPeer(p)}};
 p.wire=wire;
 pc.onconnectionstatechange=()=>{if(pc.connectionState=='failed'||pc.connectionState=='closed')dropPeer(p)};
 return p}
async function addCand(p,c){if(p.rd){try{await p.pc.addIceCandidate(c)}catch(e){}}else p.pend.push(c)}
async function flushCand(p){p.rd=true;for(const c of p.pend){try{await p.pc.addIceCandidate(c)}catch(e){}}p.pend=[]}
function diag(S){const el=$('mpd');if(el)el.textContent='Servidores: '+S.states().map(x=>x.n+(x.ok?' ✔':' ✖')).join(' · ')}
/* quita conexiones a medio abrir que nunca terminaron (si no, llenan los cupos y la sala rechaza a todos) */
function purgeStale(){const now=performance.now(),lim=window.MC_STALE||40000;for(const v of [...N.peers.values()])if(!v.id&&!v.ok&&now-v.born>lim)dropPeer(v)}

/* ---- Anfitrión ---- */
function ensureWorld(){
 if(curId){enter();return}
 const I=idx().sort((a,b)=>b.t-a.t);if(!(I[0]&&loadWorld(I[0].id)))newWorld()}
function startHost(){
 N.hosting=true;status('Creando sala…');let tries=0;
 const attempt=()=>{
  const code=rid(5),id=PFX+code;let declared=false,over=false,grace=0,to=0;
  const stop=()=>{over=true;clearTimeout(grace);clearTimeout(to)};
  const declare=()=>{if(over)return;stop();declared=true;N.sig=S;N.code=code;N.role='host';NETON=true;N.myId=0;N.peers.clear();N.players.clear();N.early.clear();
   ensureWorld();hidePanel();hud();wake();say('Sala '+code+' creada · toca el código arriba para copiarlo')};
  const S=Sigs(id,m=>{
   if(m.type=='ID-TAKEN'){if(declared||over)return;stop();S.close();if(++tries<5)attempt();else{N.hosting=false;status('No se pudo crear la sala. Intenta otra vez.')}return}
   if(!declared||N.sig!==S)return;
   if(m.type=='OFFER')hostOffer(S,m.src,m.payload);
   else if(m.type=='CANDIDATE'&&m.payload){const p=N.peers.get(m.src);
    if(p)addCand(p,m.payload.candidate);else{const a=N.early.get(m.src)||[];a.push(m.payload.candidate);N.early.set(m.src,a.slice(-40))}}
  },()=>{diag(S);if(!declared&&!over&&!grace&&S.anyOpen())grace=setTimeout(declare,900);if(declared)hud()});
  to=setTimeout(()=>{if(over||declared)return;stop();S.close();N.hosting=false;status('No se pudo contactar ningún servidor de conexión. Revisa tu internet o prueba con otra red.')},12000);
 };attempt()}
async function hostOffer(sig,src,pl){
 if(!pl||!pl.sdp||!pl.cid)return;
 const old=N.peers.get(src);
 if(old&&old.cid===pl.cid){if(old.ans)sig.send('ANSWER',src,old.ans,false);return} /* oferta repetida: solo reenvía la respuesta */
 purgeStale();
 if(!old&&N.peers.size>=MAXG)return;
 if(old)dropPeer(old);
 const p=mkPeer(src,onHost);p.cid=pl.cid;N.peers.set(src,p);
 p.pc.onicecandidate=e=>{if(e.candidate)sig.send('CANDIDATE',src,{candidate:e.candidate.toJSON(),cid:pl.cid})};
 p.pc.ondatachannel=e=>{const ch=e.channel;if(ch.label=='r'){p.r=ch;p.wire(ch)}else if(ch.label=='u'){p.u=ch;p.wire(ch)}};
 try{await p.pc.setRemoteDescription(pl.sdp);await flushCand(p);
  const early=N.early.get(src);if(early){N.early.delete(src);for(const c of early)addCand(p,c)}
  const a=await p.pc.createAnswer();await p.pc.setLocalDescription(a);
  p.ans={sdp:{type:a.type,sdp:a.sdp},cid:pl.cid};sig.send('ANSWER',src,p.ans)}catch(e){dropPeer(p)}}

/* ---- Invitado ---- */
const P2PFAIL='Se encontró la sala, pero no se pudo abrir la conexión directa (tu red o la de tu amigo la bloquea). Prueba con la misma WiFi, o pon un servidor TURN en "Avanzado".';
function startJoin(code){
 code=(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
 if(code.length<4){status('Escribe el código de la sala');return}
 if(N.joining)return;N.joining=true;
 status('Conectando a '+code+'…');
 const id=PFX+'g-'+rid(8),hostId=PFX+code,cid=rid(6);let finished=false,gotAns=false,offer=null;const timers=[];
 const fail=t=>{if(finished)return;finished=true;N.joining=false;N.cancel=null;timers.forEach(clearTimeout);clearInterval(N.rt);
  try{S.close()}catch(e){}const hp=N.peers.get('host');if(hp){hp.silent=true;dropPeer(hp)}N.peers.clear();N.role=null;N.sig=null;status(t)};
 N.cancel=()=>fail('');
 const p=mkPeer('host',(q,d)=>onClient(d));N.peers.set('host',p);
 const S=Sigs(id,async m=>{
  if(m.type=='ANSWER'&&m.payload&&m.payload.cid===cid&&!gotAns){gotAns=true;status('Sala encontrada · abriendo conexión directa…');
   try{await p.pc.setRemoteDescription(m.payload.sdp);await flushCand(p)}catch(e){fail('Error de conexión')}}
  else if(m.type=='CANDIDATE'&&m.payload&&m.payload.cid===cid)addCand(p,m.payload.candidate)
 },()=>diag(S));
 N.sig=S;
 p.r=p.pc.createDataChannel('r',{ordered:true});p.u=p.pc.createDataChannel('u',{ordered:false,maxRetransmits:0});
 p.wire(p.r);p.wire(p.u);
 p.r.onopen=()=>{if(finished)return;finished=true;N.joining=false;N.cancel=null;timers.forEach(clearTimeout);clearInterval(N.rt);
  N.role='client';p.ok=true;sendTo(p,{t:'hello',name:N.name,skin:skn.slice()});status('Descargando el mundo…');setTimeout(()=>{try{S.close()}catch(e){}},1500)};
 p.pc.onicecandidate=e=>{if(e.candidate)S.send('CANDIDATE',hostId,{candidate:e.candidate.toJSON(),cid})};
 p.pc.oniceconnectionstatechange=()=>{if(!finished&&p.pc.iceConnectionState=='failed')fail(P2PFAIL)};
 (async()=>{try{const o=await p.pc.createOffer();await p.pc.setLocalDescription(o);offer={sdp:{type:o.type,sdp:o.sdp},cid};S.send('OFFER',hostId,offer)}catch(e){fail('Error de conexión')}})();
 /* si nadie contesta, se repite la oferta (por si la sala acababa de abrirse o un servidor se conectó tarde) */
 N.rt=setInterval(()=>{if(!gotAns&&offer&&S.anyOpen())S.send('OFFER',hostId,offer,false)},4000);
 timers.push(setTimeout(()=>{if(!gotAns)fail(S.anyOpen()?'No se encontró la sala '+code+'. Revisa el código y que tu amigo siga con la sala abierta.':'No se pudo contactar los servidores de conexión. Revisa tu internet.')},14000));
 timers.push(setTimeout(()=>fail(P2PFAIL),34000))}

/* ---------- Salir ---------- */
function leave(msg){
 const was=N.role;
 if(was=='host')bcast({t:'bye'});else if(was=='client')toHost({t:'bye'});
 if(N.cancel)N.cancel();
 clearTimeout(N.tmo);clearInterval(N.rt);
 {const ps=[...N.peers.values()];ps.forEach(p=>{p.silent=true;p.dead=true});setTimeout(()=>ps.forEach(p=>{try{p.pc.close()}catch(e){}}),400)}
 N.peers.clear();N.players.clear();N.batch=[];N.eA.clear();N.eM.clear();N.early.clear();N.snap=null;
 if(N.sig){try{N.sig.close()}catch(e){}N.sig=null}
 N.role=null;N.hosting=false;N.joining=false;N.code='';NETON=false;unwake();hud();
 if(was=='client'){
  [ANI,MON,ARR,EX,DR].forEach(l=>l.length=0);started=0;paused=0;open=0;curId=null;
  $('pause').classList.add('hide');$('menu').classList.remove('hide');$('play').textContent='▶ Jugar';
  if(msg)$('sp').textContent=msg}
 else if(was=='host'&&msg)say(msg)}

/* mantiene la pantalla encendida mientras se juega en línea (si no, el celular suspende la conexión) */
async function wake(){try{if(navigator.wakeLock&&!N.wl){N.wl=await navigator.wakeLock.request('screen');N.wl.addEventListener('release',()=>{N.wl=null})}}catch(e){}}
function unwake(){try{N.wl&&N.wl.release()}catch(e){}N.wl=null}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&N.role)wake()});

/* ---------- Bucle de red (20 Hz) ---------- */
setInterval(()=>{
 if(!N.role||!started)return;N.tick++;
 const now=performance.now();
 if(N.role=='host'){
  if(N.tick%40==0)purgeStale();
  if(N.peers.size){
   bcast(Object.assign(myState(),{id:0}),true);
   if(N.tick%2==0)bcast(entsMsg(),true);
   if(N.tick%40==0)bcast({t:'time',d:dayT});
   if(N.tick%40==0)for(const p of [...N.peers.values()])if(p.ok&&now-p.last>15000)dropPeer(p)}
 }else{
  toHost(myState());
  const p=N.peers.get('host');if(p&&N.tick%40==0&&now-p.last>15000)leave('Se perdió la conexión con el anfitrión')}
 flush();
 if(N.tick%40==0){const s=skn.join('|');if(s!==N.lastSkin){N.lastSkin=s;if(N.role=='client')toHost({t:'skin',d:skn.slice()});else bcast({t:'skin',id:0,d:skn.slice()})}}
},50);
addEventListener('pagehide',()=>{if(N.role)leave()});

/* ---------- Interfaz ---------- */
const css=document.createElement('style');
css.textContent=`#mpp{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:safe center;gap:8px;color:#fff;z-index:8;padding:12px;box-sizing:border-box;overflow:auto;line-height:1.3;background:rgba(20,16,10,.82)}
#mpp.hide{display:none}#mpp h2{font:900 clamp(22px,5vw,32px) "Courier New",monospace;margin:0;text-shadow:3px 3px 0 #000}
#mpp input{padding:8px;font:16px "Courier New",monospace;border:3px solid #000;width:min(250px,80%);box-sizing:border-box;text-align:center;text-transform:none}
#mpp .sec{width:min(380px,92%);background:rgba(0,0,0,.45);border:2px solid #000;padding:8px;display:flex;flex-direction:column;align-items:center;gap:6px;font:12px/1.35 Georgia,serif}
#mpp .sec b{font:700 13px "Courier New",monospace;color:#ffeb3b}
#mpst{font:700 13px "Courier New",monospace;color:#ffeb3b;min-height:18px;text-align:center;max-width:92%}
#mps{position:fixed;left:50%;transform:translateX(-50%);top:calc(4px + env(safe-area-inset-top,0px));z-index:30;font:700 12px "Courier New",monospace;color:#fff;background:rgba(0,0,0,.6);padding:3px 10px;border-radius:10px;display:none;cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}
#mpd{font:11px "Courier New",monospace;color:#cfe;text-align:center;min-height:14px;max-width:92%}
#mpp small{opacity:.8;font:11px/1.3 Georgia,serif;text-align:center}`;
document.head.appendChild(css);
const wrap=$('wrap'),menu=$('menu');
const pan=document.createElement('div');pan.id='mpp';pan.className='hide';
pan.innerHTML=`<h2>🌐 Multijugador</h2>
<div class="sec"><b>Tu nombre</b><input id="mpn" maxlength="14" placeholder="Nombre" autocomplete="off"></div>
<div class="sec"><b>👑 Crear sala</b>Tú serás el anfitrión (usa tu mundo actual). Te daremos un código para tu amigo.<button class="mb" id="mph" style="width:100%">Crear sala</button></div>
<div class="sec"><b>🔗 Unirse a una sala</b><input id="mpj" maxlength="8" placeholder="CÓDIGO" autocomplete="off" autocapitalize="characters" style="text-transform:uppercase"><button class="mb" id="mpg" style="width:100%">Unirse</button></div>
<div class="sec"><b>⚙ Avanzado (opcional)</b><small>Servidor TURN propio para redes que bloquean la conexión directa. Formato: turn:servidor:3478,usuario,clave</small><input id="mpt" placeholder="turn:servidor:3478,usuario,clave" autocomplete="off" autocapitalize="none" spellcheck="false" style="font-size:13px;text-transform:none"></div>
<div id="mpst"></div><div id="mpd"></div><button class="mb" id="mpx">← Volver</button>`;
wrap.appendChild(pan);
const hudEl=document.createElement('div');hudEl.id='mps';document.body.appendChild(hudEl);
const btn=document.createElement('button');btn.className='mb';btn.id='mpb';btn.textContent='🌐 Multijugador';menu.insertBefore(btn,$('info'));
function status(t){$('mpst').textContent=t||''}
function hidePanel(){pan.classList.add('hide')}
function hud(){
 if(!N.role){hudEl.style.display='none';return}
 const n=N.players.size+1;
 hudEl.textContent=N.role=='host'?'🌐 Sala '+N.code+' · '+n+' jugador'+(n>1?'es':'')+' · toca para copiar':'🌐 En línea · '+n+' jugadores';
 hudEl.style.display='block'}
hudEl.onclick=()=>{if(N.role=='host'&&N.code){try{navigator.clipboard.writeText(N.code).then(()=>say('Código '+N.code+' copiado'),()=>say('Código: '+N.code))}catch(e){say('Código: '+N.code)}}};
function myName(){let n=($('mpn').value||'').trim().slice(0,14)||'Jugador'+(10+Math.random()*89|0);try{localStorage.setItem('pm_name',n)}catch(e){}N.name=n;return n}
try{$('mpn').value=localStorage.getItem('pm_name')||''}catch(e){}
btn.onclick=()=>{status('');pan.classList.remove('hide')};
$('mpx').onclick=()=>{if(N.joining&&N.cancel)N.cancel();status('');hidePanel()};
try{$('mpt').value=localStorage.getItem('pm_turn')||''}catch(e){}
$('mpt').onchange=()=>{try{localStorage.setItem('pm_turn',$('mpt').value.trim())}catch(e){}};
$('mph').onclick=()=>{if(!window.RTCPeerConnection){status('Tu navegador no soporta multijugador');return}if(N.role=='host'){status('Ya tienes una sala abierta: código '+N.code);return}if(N.role||N.hosting||N.joining)return;myName();startHost()};
$('mpg').onclick=()=>{if(!window.RTCPeerConnection){status('Tu navegador no soporta multijugador');return}if(N.role||N.hosting){status(N.role=='host'?'Ya eres anfitrión de una sala':'Ya estás conectado');return}myName();startJoin($('mpj').value)};
$('mpj').addEventListener('keydown',e=>{if(e.key=='Enter')$('mpg').click()});
$('home').addEventListener('click',()=>{if(N.role)leave()});
})();
